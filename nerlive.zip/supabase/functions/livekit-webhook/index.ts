/**
 * Supabase Edge Function: LiveKit Webhook Handler
 * Processes live room events (room_started, room_finished) for duration tracking and billing.
 */

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

serve(async (req) => {
  if (req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }

  try {
    const payload = await req.json();
    const { event, room, createdAt } = payload;

    if (!room || !room.name) {
      return new Response(JSON.stringify({ error: 'Invalid room payload' }), { status: 400 });
    }

    const roomId = room.name;
    const timestamp = createdAt ? new Date(createdAt * 1000) : new Date();

    if (event === 'room_started') {
      // Record stream session start
      const { error } = await supabase
        .from('live_sessions')
        .insert({
          room_id: roomId,
          started_at: timestamp.toISOString(),
          status: 'active'
        });

      if (error) throw error;
      console.log(`[LiveKit Webhook] Room started: ${roomId}`);
    } else if (event === 'room_finished') {
      // Calculate duration and update billing / session
      const { data: session, error: fetchError } = await supabase
        .from('live_sessions')
        .select('*')
        .eq('room_id', roomId)
        .eq('status', 'active')
        .single();

      if (fetchError || !session) {
        console.warn(`[LiveKit Webhook] Active session not found for room: ${roomId}`);
      } else {
        const startedAt = new Date(session.started_at);
        const durationSeconds = Math.floor((timestamp.getTime() - startedAt.getTime()) / 1000);
        const billingCostCents = Math.ceil(durationSeconds / 60) * 15; // Ex: R$ 0,15 por minuto de SFU

        // Update session and record billing ledger
        await supabase
          .from('live_sessions')
          .update({
            ended_at: timestamp.toISOString(),
            duration_seconds: durationSeconds,
            status: 'completed'
          })
          .eq('id', session.id);

        await supabase
          .from('financial_ledger')
          .insert({
            creator_id: session.creator_id,
            type: 'platform_fee',
            description: `Custo de streaming LiveKit (${Math.floor(durationSeconds / 60)} min)`,
            amount: billingCostCents,
            status: 'completed'
          });

        console.log(`[LiveKit Webhook] Room finished: ${roomId}. Duration: ${durationSeconds}s. Cost: ${billingCostCents} cents.`);
      }
    }

    return new Response(JSON.stringify({ received: true, event }), {
      headers: { 'Content-Type': 'application/json' },
      status: 200,
    });
  } catch (err: any) {
    console.error(`[LiveKit Webhook Error]`, err.message);
    return new Response(JSON.stringify({ error: err.message }), {
      headers: { 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});
