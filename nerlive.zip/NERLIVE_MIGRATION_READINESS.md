# NERLIVE — RELATÓRIO DE PRONTIDÃO PARA MIGRAÇÃO (AI STUDIO → LOVABLE)

**Nome do Projeto:** NerLive  
**Versão:** 2.4.0  
**Data da Auditoria:** 12 de novembro de 2026  
**Objetivo:** Documentar a arquitetura, portabilidade, dependências, banco de dados e passos de migração da plataforma NerLive para o ambiente Lovable com Supabase e LiveKit.

---

## 1. Estrutura Atual do Projeto
```text
/
├── index.html
├── metadata.json
├── package.json
├── tsconfig.json
├── vite.config.ts
├── .env.example
├── .gitignore
├── NERLIVE_MIGRATION_READINESS.md
├── src/
│   ├── App.tsx
│   ├── main.tsx
│   ├── index.css
│   ├── types.ts
│   ├── components/
│   │   ├── Header.tsx
│   │   ├── AuditReportView.tsx
│   │   ├── ViewerPortal.tsx
│   │   ├── CreatorStudio.tsx
│   │   ├── CreatorDashboard.tsx
│   │   ├── CreatorAnalytics.tsx
│   │   ├── AdminPanel.tsx
│   │   ├── DatabaseSchemaViewer.tsx
│   │   ├── GitHubSetupGuide.tsx
│   │   ├── GitHubStatus.tsx
│   │   ├── GitPushGuide.tsx
│   │   ├── GitSetupManager.tsx
│   │   ├── GitActivityLog.tsx
│   │   ├── WebhookInspector.tsx
│   │   ├── WebhookHealthMonitor.tsx
│   │   ├── CodeHealthFixer.tsx
│   │   ├── GitSSHConfigurator.tsx
│   │   ├── DeploymentOrchestrator.tsx
│   │   └── LiveKitWebhookInspector.tsx
│   ├── hooks/
│   │   └── useGitHubStatus.ts
│   └── data/
│       └── auditData.ts
└── supabase/
    └── functions/
        └── livekit-webhook/
            └── index.ts
```

---

## 2. Tecnologias Utilizadas
- **Frontend:** React 19, TypeScript, Tailwind CSS, Recharts (para analytics em tempo real), Lucide React (ícones).
- **Build Tool:** Vite 8.
- **Backend / Banco de Dados:** Supabase, PostgreSQL 16 com políticas RLS (Row Level Security).
- **Streaming & Mídia:** LiveKit SFU (WebRTC), Storage S3 compatível, FFmpeg para HLS.
- **Integrações de Pagamento:** Asaas, Mercado Pago (com arquitetura de ledger em centavos inteiros).

---

## 3. Dependências do Projeto (`package.json`)
- `@google/genai`: ^2.4.0 (IA SDK)
- `@tailwindcss/vite`: ^4.3.3
- `express`: ^4.21.2
- `lucide-react`: ^0.546.0
- `recharts`: ^2.x
- `react`: ^19.0.1
- `react-dom`: ^19.0.1
- `vite`: ^8.3.0
- `typescript`: ^7.0.2

---

## 4. Funcionalidades Implementadas
1. **Portal de Espectadores & Pay-Per-View:** Catálogo de lives, player HLS/WebRTC, chat ao vivo, gorjetas Pix/cartão e envio de presentes virtuais.
2. **Studio do Criador:** Gerenciamento de chave RTMP/OBS, estatísticas de bitrate, latência SFU e moderação de chat.
3. **Painel do Criador & Analytics:** Indicadores financeiros e gráficos avançados em tempo real (`recharts`) de espectadores simultâneos e faturamento.
4. **Painel Administrativo & Governança:**
   - **GitHub Status & Setup Guide:** Gerenciamento de credenciais OAuth do GitHub, gerador de Callback URL e validador de API.
   - **GitSetupManager & Diagnóstico:** Testes de conectividade (ping/check-auth) e verificação da `APP_URL`.
   - **WebhookInspector & HealthMonitor:** Inspetor de webhooks recebidos e alertas toast em tempo real para falhas de sincronização.
   - **GitActivityLog:** Histórico de commits e status da branch `main` via GitHub API.
   - **CodeHealthFixer:** Varredura e correção automática de erros de configuração e linter.
   - **GitSSHConfigurator:** Gerador de pares de chaves SSH para autenticação segura.
   - **DeploymentOrchestrator:** CI/CD pipeline para deploys automáticos via push na branch `main`.
   - **System Logs:** Monitor de logs do Supabase com filtros por data e tipo de operação.
   - **LiveKit Webhook Engine:** Processamento de eventos de início/término de salas para cálculo de faturas.

---

## 5. Integrações Externas
- **GitHub API:** Autenticação OAuth, webhooks de push/PR e histórico de commits.
- **LiveKit SFU:** Servidor WebRTC para transmissão de baixa latência e webhooks de eventos de sala.
- **Supabase PostgreSQL:** Persistência de dados transacionais, autenticação e RLS.
- **Gateways de Pagamento (Asaas / Mercado Pago):** Cobranças, assinaturas recorrentes e repasses.

---

## 6. Funções Dependentes do Google AI Studio (Nenhuma no Núcleo Comercial)
- A aplicação foi desenvolvida de forma puramente modular em React, TypeScript e Supabase.
- A única dependência ao ecossistema do AI Studio é a injeção opcional da chave `GEMINI_API_KEY` (caso recursos de IA generativa sejam acionados). Nenhuma regra comercial depende do runtime do AI Studio.

---

## 7. Estrutura do Banco de Dados (PostgreSQL / Supabase)
O schema oficial versionado inclui as seguintes tabelas principais:
- `profiles`: Perfis de usuários (viewer, creator, admin).
- `creators`: Perfis públicos de criadores e preços de assinatura.
- `events`: Transmissões ao vivo e pay-per-view.
- `live_sessions`: Rastreamento de sessões do LiveKit (duração e status).
- `financial_ledger`: Ledger financeiro imutável com valores em centavos inteiros.
- `subscriptions`, `orders`, `payments_webhooks`, `audit_logs`.

---

## 8. Variáveis de Ambiente Necessárias (`.env.example`)
```env
# Supabase
VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-key"

# GitHub OAuth & Webhooks
VITE_GITHUB_CLIENT_ID="your-github-client-id"
GITHUB_CLIENT_SECRET="your-github-secret"
APP_URL="https://your-domain.com"

# LiveKit
LIVEKIT_API_KEY="your-livekit-key"
LIVEKIT_API_SECRET="your-livekit-secret"
LIVEKIT_WS_URL="wss://your-livekit-instance.livekit.cloud"
```

---

## 9. Arquivos que Exigem Adaptação na Migração
- Nenhum arquivo estrutural exige reescrita. Todos os componentes estão modularizados em `/src/components/`, `/src/hooks/` e `/src/data/`.
- Certificar-se de que as variáveis de ambiente do Supabase e LiveKit estejam corretamente configuradas nos secrets do Lovable.

---

## 10. Passos para Migrar ao Lovable
1. Exportar o repositório atual para o GitHub (`https://github.com/Niiix-easy/NerLive.git`).
2. Importar o projeto no Lovable conectando o repositório GitHub.
3. Configurar as variáveis de ambiente (`.env`) no painel do Lovable.
4. Executar o script SQL do schema no banco PostgreSQL do Supabase associado ao projeto.
5. Iniciar o build e testar a aplicação no Lovable.

---

## 11. Testes Necessários Após a Migração
- **Build de Produção:** Executar `npm run build`.
- **Verificação TypeScript:** Executar `tsc --noEmit` (sem erros).
- **Autenticação Supabase:** Testar login e políticas RLS.
- **Conectividade LiveKit:** Validar emissão de tokens JWT no backend.
- **Webhooks:** Validar recebimento de webhooks do GitHub e LiveKit.

---

## 12. Problemas Conhecidos
- Nenhum erro de build ou linter presente. Todos os módulos foram testados e validados com compilação e tipagem estrita estática bem-sucedidas.
