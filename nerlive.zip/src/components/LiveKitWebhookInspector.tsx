import { useState } from 'react';
import { Radio, Send, CheckCircle2, Clock, DollarSign, Server } from 'lucide-react';

interface LiveKitLog {
  id: string;
  event: 'room_started' | 'room_finished';
  roomName: string;
  durationSeconds?: number;
  costCents?: number;
  timestamp: string;
}

export function LiveKitWebhookInspector() {
  const [logs, setLogs] = useState<LiveKitLog[]>([
    {
      id: 'lk-001',
      event: 'room_finished',
      roomName: 'room_techmaster_live_99',
      durationSeconds: 3600, // 1 hour
      costCents: 900, // R$ 9,00 (60 min * R$ 0,15)
      timestamp: '17:01:22'
    },
    {
      id: 'lk-002',
      event: 'room_started',
      roomName: 'room_gabrielamusic_live_04',
      timestamp: '16:30:00'
    }
  ]);

  const [simulating, setSimulating] = useState<boolean>(false);

  const handleSimulateLiveKitEvent = (eventType: 'room_started' | 'room_finished') => {
    setSimulating(true);

    setTimeout(() => {
      const isFinished = eventType === 'room_finished';
      const duration = isFinished ? 2400 : undefined; // 40 minutes
      const cost = isFinished ? 600 : undefined; // R$ 6,00

      const newLog: LiveKitLog = {
        id: `lk-${Date.now().toString().slice(-4)}`,
        event: eventType,
        roomName: 'room_nerlive_exclusive_01',
        durationSeconds: duration,
        costCents: cost,
        timestamp: new Date().toLocaleTimeString()
      };

      setLogs([newLog, ...logs]);
      setSimulating(false);
    }, 800);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <Radio className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">LiveKit Webhook & Billing Engine</h2>
            <p className="text-xs text-slate-400">Processamento de eventos SFU (room_started / room_finished) para cálculo de faturas e duração.</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleSimulateLiveKitEvent('room_started')}
            disabled={simulating}
            className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-xl flex items-center space-x-1.5 transition-colors shadow-lg shadow-violet-600/30 disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Simular Room Started</span>
          </button>
          <button
            onClick={() => handleSimulateLiveKitEvent('room_finished')}
            disabled={simulating}
            className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold rounded-xl flex items-center space-x-1.5 transition-colors shadow-lg shadow-pink-600/30 disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            <span>Simular Room Finished</span>
          </button>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] font-mono text-slate-400 uppercase">
                <th className="py-3 px-4">Evento LiveKit</th>
                <th className="py-3 px-4">Nome da Sala (Room ID)</th>
                <th className="py-3 px-4">Duração</th>
                <th className="py-3 px-4">Custo Fatura (SFU)</th>
                <th className="py-3 px-4">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-xs font-mono">
              {logs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-900/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase inline-flex items-center space-x-1 ${
                      log.event === 'room_started' ? 'bg-violet-500/20 text-violet-300 border border-violet-500/35' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/35'
                    }`}>
                      <Radio className="w-3 h-3" />
                      <span>{log.event}</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-white">{log.roomName}</td>
                  <td className="py-3.5 px-4 text-slate-300">
                    {log.durationSeconds ? `${Math.floor(log.durationSeconds / 60)} min (${log.durationSeconds}s)` : 'Em andamento'}
                  </td>
                  <td className="py-3.5 px-4 text-emerald-400 font-bold">
                    {log.costCents ? `R$ ${(log.costCents / 100).toFixed(2)}` : 'Calculando...'}
                  </td>
                  <td className="py-3.5 px-4 text-slate-400">{log.timestamp}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
