import { useState } from 'react';
import { Video, Users, DollarSign, Gift, Heart, Send, Lock, Play, Sparkles, Radio, CheckCircle2 } from 'lucide-react';
import { LiveEvent, ChatMessage } from '../types';
import { MOCK_EVENTS, MOCK_CHAT_MESSAGES } from '../data/auditData';

export function ViewerPortal() {
  const [selectedEvent, setSelectedEvent] = useState<LiveEvent | null>(MOCK_EVENTS[0]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(MOCK_CHAT_MESSAGES);
  const [inputText, setInputText] = useState('');
  const [hasAccess, setHasAccess] = useState<boolean>(true);
  const [showPaywallModal, setShowPaywallModal] = useState<boolean>(false);
  const [showTipModal, setShowTipModal] = useState<boolean>(false);
  const [tipAmount, setTipAmount] = useState<number>(1000); // R$ 10,00 in cents
  const [selectedGift, setSelectedGift] = useState<string>('☕ Café Expresso (R$ 5,00)');
  const [successNotification, setSuccessNotification] = useState<string | null>(null);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      senderName: 'Você (Espectador)',
      senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages([...chatMessages, newMsg]);
    setInputText('');
  };

  const handleSendTip = () => {
    const newMsg: ChatMessage = {
      id: `tip-${Date.now()}`,
      senderName: 'Você (Espectador)',
      senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      text: `Enviou uma gorjeta de R$ ${(tipAmount / 100).toFixed(2)}! 💸`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isTip: true,
      tipAmount: tipAmount
    };
    setChatMessages([...chatMessages, newMsg]);
    setShowTipModal(false);
    setSuccessNotification(`Gorjeta de R$ ${(tipAmount / 100).toFixed(2)} enviada com sucesso!`);
    setTimeout(() => setSuccessNotification(null), 4000);
  };

  const handleSendGift = (giftName: string, price: number) => {
    const newMsg: ChatMessage = {
      id: `gift-${Date.now()}`,
      senderName: 'Você (Espectador)',
      senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
      text: `Enviou o presente virtual ${giftName}! 🎁`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      giftName: giftName
    };
    setChatMessages([...chatMessages, newMsg]);
    setSuccessNotification(`Presente ${giftName} enviado com sucesso!`);
    setTimeout(() => setSuccessNotification(null), 4000);
  };

  const handleUnlockPPV = () => {
    setHasAccess(true);
    setShowPaywallModal(false);
    setSuccessNotification('Ingresso Pay-Per-View adquirido com sucesso via Gateway!');
    setTimeout(() => setSuccessNotification(null), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {successNotification && (
        <div className="mb-6 bg-emerald-500/20 border border-emerald-500/30 text-emerald-200 px-4 py-3 rounded-xl flex items-center space-x-3 shadow-lg animate-fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <span className="text-sm font-medium">{successNotification}</span>
        </div>
      )}

      {selectedEvent ? (
        // Active Stream & Chat Room View
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Video Player & Details (2 Cols) */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl">
              {/* Player Container */}
              <div className="relative aspect-video bg-slate-950 flex items-center justify-center">
                {selectedEvent.isPayPerView && !hasAccess ? (
                  <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center text-center p-6 z-10">
                    <div className="w-16 h-16 rounded-2xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400 mb-4 shadow-xl">
                      <Lock className="w-8 h-8" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">Conteúdo Exclusivo Pay-Per-View</h3>
                    <p className="text-slate-300 max-w-md text-sm mb-6">
                      Este evento requer aquisição de ingresso para liberação do stream em tempo real via LiveKit SFU.
                    </p>
                    <button
                      onClick={() => setShowPaywallModal(true)}
                      className="px-6 py-3 rounded-xl bg-gradient-to-r from-violet-600 to-indigo-600 text-white font-semibold text-sm shadow-lg shadow-violet-600/40 hover:from-violet-500 hover:to-indigo-500 transition-all flex items-center space-x-2"
                    >
                      <Sparkles className="w-4 h-4" />
                      <span>Desbloquear Acesso por R$ {(selectedEvent.price / 100).toFixed(2)}</span>
                    </button>
                  </div>
                ) : (
                  <>
                    <img
                      src={selectedEvent.thumbnailUrl}
                      alt={selectedEvent.title}
                      className="w-full h-full object-cover opacity-80"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/40 flex flex-col justify-between p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 bg-red-500/90 text-white px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider shadow-lg">
                          <Radio className="w-3.5 h-3.5 animate-pulse" />
                          <span>AO VIVO (LiveKit SFU)</span>
                        </div>
                        <div className="flex items-center space-x-2 bg-slate-900/80 backdrop-blur-md text-slate-200 px-3 py-1 rounded-full text-xs font-medium border border-slate-700">
                          <Users className="w-3.5 h-3.5 text-violet-400" />
                          <span>{selectedEvent.viewersCount} espectadores</span>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <img
                            src={selectedEvent.creatorAvatar}
                            alt={selectedEvent.creatorName}
                            className="w-10 h-10 rounded-full border-2 border-violet-500 object-cover shadow-lg"
                          />
                          <div>
                            <h4 className="text-white font-bold text-sm">{selectedEvent.creatorName}</h4>
                            <span className="text-violet-300 text-xs">Transmissão Segura de Baixa Latência</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <button
                            onClick={() => setShowTipModal(true)}
                            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/30 flex items-center space-x-1.5 transition-all"
                          >
                            <DollarSign className="w-4 h-4" />
                            <span>Enviar Gorjeta</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>

              {/* Event Info */}
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30">
                    {selectedEvent.category}
                  </span>
                  <button
                    onClick={() => setSelectedEvent(null)}
                    className="text-xs text-slate-400 hover:text-white transition-colors underline"
                  >
                    ← Voltar para todos os eventos
                  </button>
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">{selectedEvent.title}</h2>
                <p className="text-slate-300 text-sm leading-relaxed">{selectedEvent.description}</p>
              </div>
            </div>

            {/* Virtual Gifts Quick Bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <h3 className="text-sm font-bold text-white mb-3 flex items-center space-x-2">
                <Gift className="w-4 h-4 text-pink-400" />
                <span>Enviar Presente Virtual ao Criador</span>
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {[
                  { name: '☕ Café', price: 500 },
                  { name: '🌹 Rosa', price: 1000 },
                  { name: '🚀 Foguete', price: 5000 },
                  { name: '👑 Coroa', price: 10000 }
                ].map((gift, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendGift(gift.name, gift.price)}
                    className="bg-slate-950 border border-slate-800 hover:border-violet-500/60 p-3 rounded-xl text-left transition-all group"
                  >
                    <div className="text-sm font-bold text-white group-hover:text-violet-300">{gift.name}</div>
                    <div className="text-xs text-emerald-400 font-mono mt-1">R$ {(gift.price / 100).toFixed(2)}</div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Live Chat & Interactions (1 Col) */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[700px] shadow-2xl overflow-hidden">
            <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                <Users className="w-4 h-4 text-violet-400" />
                <span>Chat ao Vivo & Interações</span>
              </h3>
              <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                Conectado
              </span>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {chatMessages.map((msg) => (
                <div
                  key={msg.id}
                  className={`p-3 rounded-xl text-xs space-y-1 ${
                    msg.isTip
                      ? 'bg-emerald-950/40 border border-emerald-500/30'
                      : msg.giftName
                      ? 'bg-pink-950/40 border border-pink-500/30'
                      : 'bg-slate-950/50 border border-slate-800/80'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <img src={msg.senderAvatar} alt={msg.senderName} className="w-6 h-6 rounded-full object-cover" />
                      <span className="font-bold text-white">{msg.senderName}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">{msg.timestamp}</span>
                  </div>
                  <p className="text-slate-300 pl-8">{msg.text}</p>
                </div>
              ))}
            </div>

            {/* Chat Input */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-800 bg-slate-950/60 flex items-center space-x-2">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder="Envie uma mensagem no chat..."
                className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-violet-500"
              />
              <button
                type="submit"
                className="bg-violet-600 hover:bg-violet-500 text-white p-2 rounded-xl transition-all shadow-md shadow-violet-600/30"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
          </div>
        </div>
      ) : (
        // Event Catalog Grid
        <div>
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-2">Transmissões ao Vivo & Catálogo PPV</h2>
            <p className="text-slate-400 text-sm">
              Explore criadores independentes, participe de aulas ao vivo e adquira ingressos pay-per-view exclusivos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {MOCK_EVENTS.map((event) => (
              <div
                key={event.id}
                onClick={() => {
                  setSelectedEvent(event);
                  setHasAccess(!event.isPayPerView);
                }}
                className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl hover:border-violet-500/50 transition-all cursor-pointer group"
              >
                <div className="relative aspect-video bg-slate-950 overflow-hidden">
                  <img
                    src={event.thumbnailUrl}
                    alt={event.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300 opacity-80"
                  />
                  <div className="absolute top-3 left-3 flex items-center space-x-2">
                    {event.isLive ? (
                      <span className="bg-red-500 text-white px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider flex items-center space-x-1 shadow-md">
                        <Radio className="w-3 h-3 animate-pulse" />
                        <span>AO VIVO</span>
                      </span>
                    ) : (
                      <span className="bg-slate-900/90 text-slate-300 px-2.5 py-0.5 rounded-full text-xs font-medium border border-slate-700">
                        Agendado
                      </span>
                    )}
                  </div>
                  {event.isPayPerView && (
                    <div className="absolute top-3 right-3 bg-violet-600 text-white px-2.5 py-1 rounded-lg text-xs font-bold shadow-lg flex items-center space-x-1">
                      <Lock className="w-3 h-3" />
                      <span>R$ {(event.price / 100).toFixed(2)}</span>
                    </div>
                  )}
                </div>
                <div className="p-5 space-y-3">
                  <div className="flex items-center space-x-3">
                    <img src={event.creatorAvatar} alt={event.creatorName} className="w-8 h-8 rounded-full object-cover border border-violet-500" />
                    <div>
                      <h4 className="text-white font-bold text-xs">{event.creatorName}</h4>
                      <span className="text-slate-400 text-[10px]">{event.category}</span>
                    </div>
                  </div>
                  <h3 className="text-base font-bold text-white group-hover:text-violet-300 transition-colors line-clamp-1">
                    {event.title}
                  </h3>
                  <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">{event.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Paywall Modal */}
      {showPaywallModal && selectedEvent && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-6 shadow-2xl">
            <div className="text-center">
              <div className="w-12 h-12 rounded-2xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400 mx-auto mb-4">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Desbloquear Evento PPV</h3>
              <p className="text-slate-300 text-sm mt-1">{selectedEvent.title}</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2 text-sm">
              <div className="flex justify-between text-slate-300">
                <span>Ingresso Exclusivo</span>
                <span className="font-bold text-white">R$ {(selectedEvent.price / 100).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-slate-300">
                <span>Taxa da Plataforma NerLive</span>
                <span className="text-emerald-400 font-mono">Inclusa</span>
              </div>
              <div className="border-t border-slate-800 pt-2 flex justify-between font-bold text-white">
                <span>Total</span>
                <span className="text-violet-400">R$ {(selectedEvent.price / 100).toFixed(2)}</span>
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowPaywallModal(false)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-sm transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleUnlockPPV}
                className="flex-1 px-4 py-2.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-sm shadow-lg shadow-violet-600/30 transition-all"
              >
                Confirmar Pagamento
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Tip Modal */}
      {showTipModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-6 shadow-2xl">
            <div className="text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto mb-4">
                <DollarSign className="w-6 h-6" />
              </div>
              <h3 className="text-xl font-bold text-white">Enviar Gorjeta (Pix / Cartão)</h3>
              <p className="text-slate-300 text-sm mt-1">Apoie diretamente o criador desta transmissão.</p>
            </div>

            <div className="grid grid-cols-3 gap-3">
              {[500, 1000, 2500, 5000, 10000, 20000].map((amt) => (
                <button
                  key={amt}
                  onClick={() => setTipAmount(amt)}
                  className={`py-3 rounded-xl border text-sm font-bold transition-all ${
                    tipAmount === amt
                      ? 'bg-emerald-600 text-white border-emerald-500 shadow-lg shadow-emerald-600/30'
                      : 'bg-slate-950 text-slate-300 border-slate-800 hover:bg-slate-800'
                  }`}
                >
                  R$ {(amt / 100).toFixed(2)}
                </button>
              ))}
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => setShowTipModal(false)}
                className="flex-1 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-sm transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleSendTip}
                className="flex-1 px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-lg shadow-emerald-600/30 transition-all"
              >
                Enviar R$ {(tipAmount / 100).toFixed(2)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
