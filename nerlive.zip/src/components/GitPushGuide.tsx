import { useState } from 'react';
import { GitBranch, Terminal, Copy, Check, ExternalLink, ShieldCheck, CheckCircle2, Lock, Key } from 'lucide-react';

export function GitPushGuide() {
  const [patToken, setPatToken] = useState<string>('');
  const [showToken, setShowToken] = useState<boolean>(false);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  const repositoryUrl = 'https://github.com/Niiix-easy/NerLive.git';
  const maskedCommand = patToken
    ? `git push https://${patToken}@github.com/Niiix-easy/NerLive.git main --force`
    : `git push https://<SEU_TOKEN_GITHUB>@github.com/Niiix-easy/NerLive.git main --force`;

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 3000);
  };

  const toggleStep = (step: number) => {
    if (completedSteps.includes(step)) {
      setCompletedSteps(completedSteps.filter(s => s !== step));
    } else {
      setCompletedSteps([...completedSteps, step]);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
            <GitBranch className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Guia de Sincronização Git & GitHub CLI</h2>
            <p className="text-xs text-slate-400">Passo a passo para realizar o push do projeto NerLive para <code className="text-indigo-300">Niiix-easy/NerLive</code>.</p>
          </div>
        </div>
        <div className="px-3.5 py-1.5 rounded-xl border border-indigo-500/30 bg-indigo-500/10 text-indigo-400 text-xs font-mono font-semibold">
          Repositório: Niiix-easy/NerLive
        </div>
      </div>

      {/* Steps List */}
      <div className="space-y-6">
        {/* Step 1 */}
        <div className={`p-5 rounded-xl border transition-all ${completedSteps.includes(1) ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => toggleStep(1)}
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  completedSteps.includes(1) ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {completedSteps.includes(1) ? <Check className="w-3.5 h-3.5" /> : '1'}
              </button>
              <h4 className="text-sm font-bold text-white">Gerar Personal Access Token (PAT) no GitHub</h4>
            </div>
            <a
              href="https://github.com/settings/tokens/new"
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center space-x-1"
            >
              <span>Criar Token no GitHub</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed mb-3">
            O GitHub não aceita senhas comuns via linha de comando. Acesse as configurações de desenvolvedor do GitHub, gere um <strong className="text-slate-200">Personal Access Token (classic)</strong> com escopo total <code className="text-indigo-300">repo</code> e copie o token gerado.
          </p>
        </div>

        {/* Step 2 */}
        <div className={`p-5 rounded-xl border transition-all ${completedSteps.includes(2) ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => toggleStep(2)}
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  completedSteps.includes(2) ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {completedSteps.includes(2) ? <Check className="w-3.5 h-3.5" /> : '2'}
              </button>
              <h4 className="text-sm font-bold text-white">Configurar Credencial e Inserir Token</h4>
            </div>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed mb-3">
            Insira seu token abaixo para gerar o comando pronto com autenticação embutida, ou configure via SSH.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-3">
            <div>
              <label className="block text-xs font-mono text-slate-400 mb-1.5">GitHub Personal Access Token (PAT)</label>
              <input
                type="password"
                value={patToken}
                onChange={(e) => setPatToken(e.target.value)}
                placeholder="ghp_xxxxxxxxxxxxxxxxxxxx"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
              />
            </div>
            <div className="flex items-end">
              <span className="text-[11px] text-slate-500 font-mono pb-2">O token não é armazenado em servidores externos.</span>
            </div>
          </div>
        </div>

        {/* Step 3 */}
        <div className={`p-5 rounded-xl border transition-all ${completedSteps.includes(3) ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => toggleStep(3)}
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  completedSteps.includes(3) ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {completedSteps.includes(3) ? <Check className="w-3.5 h-3.5" /> : '3'}
              </button>
              <h4 className="text-sm font-bold text-white">Executar o Comando de Push no Terminal</h4>
            </div>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed mb-3">
            Execute o comando abaixo no terminal da sua máquina ou ambiente para enviar todos os arquivos do projeto NerLive:
          </p>
          <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <code className="text-xs font-mono text-indigo-300 overflow-x-auto pr-3">
              {maskedCommand}
            </code>
            <button
              onClick={() => handleCopy(maskedCommand, 'push-cmd')}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition-colors flex-shrink-0 shadow-md shadow-indigo-600/30"
            >
              {copiedCmd === 'push-cmd' ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCmd === 'push-cmd' ? 'Copiado!' : 'Copiar'}</span>
            </button>
          </div>
        </div>

        {/* Step 4: Alternative SSH */}
        <div className={`p-5 rounded-xl border transition-all ${completedSteps.includes(4) ? 'bg-emerald-950/20 border-emerald-500/30' : 'bg-slate-950 border-slate-800'}`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => toggleStep(4)}
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  completedSteps.includes(4) ? 'bg-emerald-500 text-slate-950' : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {completedSteps.includes(4) ? <Check className="w-3.5 h-3.5" /> : '4'}
              </button>
              <h4 className="text-sm font-bold text-white">Alternativa via SSH (Chaves SSH)</h4>
            </div>
          </div>
          <p className="text-xs text-slate-400 leading-relaxed mb-3">
            Se você possui chaves SSH cadastradas no seu GitHub, configure o remote SSH executando:
          </p>
          <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
            <code className="text-xs font-mono text-indigo-300 overflow-x-auto pr-3">
              git remote set-url origin git@github.com:Niiix-easy/NerLive.git && git push -u origin main --force
            </code>
            <button
              onClick={() => handleCopy('git remote set-url origin git@github.com:Niiix-easy/NerLive.git && git push -u origin main --force', 'ssh-cmd')}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg flex items-center space-x-1.5 transition-colors flex-shrink-0"
            >
              {copiedCmd === 'ssh-cmd' ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedCmd === 'ssh-cmd' ? 'Copiado!' : 'Copiar'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
