import { Radio, ShieldCheck, Users, DollarSign, Database, Video, Sparkles } from 'lucide-react';
import { UserRole } from '../types';

interface HeaderProps {
  activeTab: 'audit' | 'viewer' | 'studio' | 'dashboard' | 'admin' | 'schema';
  setActiveTab: (tab: 'audit' | 'viewer' | 'studio' | 'dashboard' | 'admin' | 'schema') => void;
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
}

export function Header({ activeTab, setActiveTab, currentRole, setCurrentRole }: HeaderProps) {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setActiveTab('audit')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-violet-600 via-indigo-600 to-pink-500 flex items-center justify-center shadow-lg shadow-violet-500/30">
              <Radio className="w-5 h-5 text-white animate-pulse" />
            </div>
            <div>
              <span className="text-xl font-black bg-gradient-to-r from-violet-400 via-indigo-300 to-pink-400 bg-clip-text text-transparent">
                NERLIVE
              </span>
              <span className="text-xs block text-slate-400 font-mono">Platform Audit & Engine v2.4</span>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="hidden md:flex items-center space-x-1">
            <button
              onClick={() => setActiveTab('audit')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'audit'
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <ShieldCheck className="w-4 h-4 text-violet-300" />
              <span>Auditoria Master</span>
            </button>

            <button
              onClick={() => setActiveTab('viewer')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'viewer'
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Video className="w-4 h-4 text-pink-300" />
              <span>Assistir Lives & PPV</span>
            </button>

            <button
              onClick={() => setActiveTab('studio')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'studio'
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Radio className="w-4 h-4 text-indigo-300" />
              <span>Studio ao Vivo</span>
            </button>

            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'dashboard'
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <DollarSign className="w-4 h-4 text-emerald-300" />
              <span>Painel do Criador</span>
            </button>

            <button
              onClick={() => setActiveTab('admin')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'admin'
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Users className="w-4 h-4 text-amber-300" />
              <span>Administração</span>
            </button>

            <button
              onClick={() => setActiveTab('schema')}
              className={`px-3 py-2 rounded-lg text-sm font-medium transition-colors flex items-center space-x-1.5 ${
                activeTab === 'schema'
                  ? 'bg-violet-600 text-white shadow-md shadow-violet-600/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Database className="w-4 h-4 text-cyan-300" />
              <span>Schema SQL</span>
            </button>
          </nav>

          {/* Role Switcher */}
          <div className="flex items-center space-x-3">
            <div className="hidden lg:flex items-center space-x-2 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
              <Sparkles className="w-4 h-4 text-violet-400" />
              <span className="text-xs text-slate-400">Perfil:</span>
              <select
                value={currentRole}
                onChange={(e) => setCurrentRole(e.target.value as UserRole)}
                className="bg-transparent text-sm font-medium text-white focus:outline-none cursor-pointer"
              >
                <option value="viewer" className="bg-slate-900 text-white">Espectador</option>
                <option value="creator" className="bg-slate-900 text-white">Criador de Conteúdo</option>
                <option value="admin" className="bg-slate-900 text-white">Administrador</option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
