import { useState, useEffect } from 'react';
import { GitCommit, GitBranch, RefreshCw, CheckCircle2, AlertTriangle, ExternalLink, ShieldCheck } from 'lucide-react';

interface CommitItem {
  sha: string;
  message: string;
  author: string;
  avatar: string;
  date: string;
  url: string;
}

export function GitActivityLog() {
  const [commits, setCommits] = useState<CommitItem[]>([]);
  const [branchStatus, setBranchStatus] = useState<{ name: string; protected: boolean; sha: string } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchGitHubActivity = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch commits from GitHub API for Niiix-easy/NerLive
      const commitsRes = await fetch('https://api.github.com/repos/Niiix-easy/NerLive/commits?per_page=5');
      const branchRes = await fetch('https://api.github.com/repos/Niiix-easy/NerLive/branches/main');

      if (commitsRes.ok && branchRes.ok) {
        const commitsData = await commitsRes.json();
        const branchData = await branchRes.json();

        const formattedCommits: CommitItem[] = commitsData.map((c: any) => ({
          sha: c.sha.substring(0, 7),
          message: c.commit.message,
          author: c.commit.author.name,
          avatar: c.author?.avatar_url || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
          date: new Date(c.commit.author.date).toLocaleString(),
          url: c.html_url
        }));

        setCommits(formattedCommits);
        setBranchStatus({
          name: branchData.name,
          protected: branchData.protected || false,
          sha: branchData.commit.sha.substring(0, 7)
        });
      } else {
        throw new Error('Falha ao consultar a API do GitHub (Rate limit ou repositório privado).');
      }
    } catch (err: any) {
      setError(err.message || 'Erro de conexão com o GitHub API');
      // Fallback mock commits so UI is fully rich
      setCommits([
        {
          sha: '974a84b',
          message: 'feat: Add useGitHubStatus hook, GitHubSetupGuide, and GitHubStatus UI components',
          author: 'NerLive Engineer',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
          date: '2026-11-12 17:14:41',
          url: 'https://github.com/Niiix-easy/NerLive/commit/974a84b'
        },
        {
          sha: '1daa580',
          message: 'Initial commit: NerLive platform & technical audit',
          author: 'NerLive Engineer',
          avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80',
          date: '2026-11-12 17:06:33',
          url: 'https://github.com/Niiix-easy/NerLive/commit/1daa580'
        }
      ]);
      setBranchStatus({
        name: 'main',
        protected: true,
        sha: '974a84b'
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchGitHubActivity();
  }, []);

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <GitCommit className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Git Activity Log & Sincronização</h2>
            <p className="text-xs text-slate-400">Histórico de commits recentes e status da branch principal via GitHub API.</p>
          </div>
        </div>

        <button
          onClick={fetchGitHubActivity}
          disabled={loading}
          className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center space-x-2 transition-colors border border-slate-700 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 text-violet-400 ${loading ? 'animate-spin' : ''}`} />
          <span>{loading ? 'Atualizando...' : 'Atualizar Atividade'}</span>
        </button>
      </div>

      {error && (
        <div className="bg-amber-500/20 border border-amber-500/30 text-amber-200 px-4 py-3 rounded-xl flex items-center space-x-3 text-xs">
          <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>{error} (Exibindo dados de cache / fallback local)</span>
        </div>
      )}

      {/* Branch Status Overview */}
      {branchStatus && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center space-x-3">
            <GitBranch className="w-5 h-5 text-violet-400" />
            <div>
              <div className="text-[10px] font-mono text-slate-400">Branch Ativa</div>
              <div className="text-sm font-bold text-white font-mono">{branchStatus.name}</div>
            </div>
          </div>
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center space-x-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <div>
              <div className="text-[10px] font-mono text-slate-400">Último Commit SHA</div>
              <div className="text-sm font-bold text-emerald-400 font-mono">{branchStatus.sha}</div>
            </div>
          </div>
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center space-x-3">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            <div>
              <div className="text-[10px] font-mono text-slate-400">Proteção de Branch</div>
              <div className="text-sm font-bold text-white">{branchStatus.protected ? 'Ativada' : 'Desativada'}</div>
            </div>
          </div>
        </div>
      )}

      {/* Commits List */}
      <div className="space-y-3">
        <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Últimos Commits no Repositório</h3>
        <div className="space-y-3">
          {commits.map((commit) => (
            <div
              key={commit.sha}
              className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 hover:border-violet-500/40 transition-colors"
            >
              <div className="flex items-start space-x-3">
                <img src={commit.avatar} alt={commit.author} className="w-9 h-9 rounded-full object-cover border border-violet-500/30 mt-0.5" />
                <div className="space-y-1">
                  <div className="text-sm font-bold text-white leading-snug">{commit.message}</div>
                  <div className="flex items-center space-x-3 text-xs text-slate-400">
                    <span className="font-semibold text-slate-300">{commit.author}</span>
                    <span>•</span>
                    <span className="font-mono">{commit.date}</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3 self-end sm:self-auto">
                <span className="px-2.5 py-1 rounded-lg bg-violet-600/20 text-violet-300 border border-violet-500/30 text-xs font-mono font-bold">
                  {commit.sha}
                </span>
                <a
                  href={commit.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg transition-colors"
                  title="Ver no GitHub"
                >
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
