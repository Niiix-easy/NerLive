import { useState, useEffect } from 'react';
import { AlertTriangle, X, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface ToastAlert {
  id: string;
  title: string;
  message: string;
  type: 'error' | 'success';
  timestamp: string;
}

export function WebhookHealthMonitor() {
  const [toasts, setToasts] = useState<ToastAlert[]>([]);

  useEffect(() => {
    // Listen to custom webhook test events or simulate an initial alert for demonstration if needed
    const handleNewWebhookLog = (e: CustomEvent) => {
      const log = e.detail;
      if (log.status === 'failed' || log.statusCode !== 200) {
        const newToast: ToastAlert = {
          id: `toast-${Date.now()}`,
          title: `Alerta Webhook: ${log.event.toUpperCase()} falhou (HTTP ${log.statusCode})`,
          message: log.error || 'Falha de assinatura ou processamento de sincronização.',
          type: 'error',
          timestamp: new Date().toLocaleTimeString()
        };
        setToasts((prev) => [...prev, newToast]);
      }
    };

    window.addEventListener('nerlive_webhook_event' as any, handleNewWebhookLog);
    return () => {
      window.removeEventListener('nerlive_webhook_event' as any, handleNewWebhookLog);
    };
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter(t => t.id !== id));
  };

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 space-y-3 max-w-md w-full px-4 pointer-events-none">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className="pointer-events-auto bg-slate-900 border border-red-500/40 text-slate-100 p-4 rounded-2xl shadow-2xl backdrop-blur-md flex items-start space-x-3 animate-fade-in"
        >
          <div className="w-9 h-9 rounded-xl bg-red-500/20 border border-red-500/30 flex items-center justify-center text-red-400 flex-shrink-0 mt-0.5">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-white">{toast.title}</h4>
              <span className="text-[10px] font-mono text-slate-500">{toast.timestamp}</span>
            </div>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">{toast.message}</p>
          </div>
          <button
            onClick={() => removeToast(toast.id)}
            className="text-slate-400 hover:text-white transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ))}
    </div>
  );
}
