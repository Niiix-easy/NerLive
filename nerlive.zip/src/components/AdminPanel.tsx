import { ShieldCheck, Users, DollarSign, Settings, Key, ExternalLink, CheckCircle2, Copy, Check, Lock, Code } from 'lucide-react';
import { GitHubSetupGuide } from './GitHubSetupGuide';
import { GitHubStatus } from './GitHubStatus';
import { GitPushGuide } from './GitPushGuide';
import { GitSetupManager } from './GitSetupManager';
import { WebhookInspector } from './WebhookInspector';
import { GitActivityLog } from './GitActivityLog';
import { CodeHealthFixer } from './CodeHealthFixer';
import { GitSSHConfigurator } from './GitSSHConfigurator';
import { DeploymentOrchestrator } from './DeploymentOrchestrator';
import { SystemLogs } from './SystemLogs';
import { LiveKitWebhookInspector } from './LiveKitWebhookInspector';

export function AdminPanel() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono font-semibold mb-2 border border-amber-500/30">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>PAINEL ADMINISTRATIVO NERLIVE</span>
          </div>
          <h1 className="text-3xl font-black text-white">Governança & Integrações Externas</h1>
        </div>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="text-xs font-mono text-slate-400 mb-1">Comissão Total (Plataforma)</div>
          <div className="text-3xl font-black text-white">R$ 18.940,00</div>
          <div className="text-xs text-emerald-400 mt-2 font-mono">Taxa padrão: 10%</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="text-xs font-mono text-slate-400 mb-1">Criadores Ativos</div>
          <div className="text-3xl font-black text-white">348</div>
          <div className="text-xs text-violet-400 mt-2 font-mono">12 em transmissão agora</div>
        </div>
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="text-xs font-mono text-slate-400 mb-1">Status do LiveKit SFU</div>
          <div className="text-3xl font-black text-emerald-400">100% Operacional</div>
          <div className="text-xs text-slate-400 mt-2 font-mono">Cluster VPS SP-01</div>
        </div>
      </div>

      {/* LiveKit Webhook & Billing Engine */}
      <LiveKitWebhookInspector />

      {/* Live GitHub OAuth Connection Status */}
      <GitHubStatus />

      {/* System Logs (Supabase Audit Stream) */}
      <SystemLogs />

      {/* Deployment Orchestrator CI/CD */}
      <DeploymentOrchestrator />

      {/* Git SSH Configurator */}
      <GitSSHConfigurator />

      {/* Code Health & Auto-Fixer */}
      <CodeHealthFixer />

      {/* Git Activity Log & Sync Status */}
      <GitActivityLog />

      {/* Webhook Inspector Dashboard */}
      <WebhookInspector />

      {/* Git Setup Manager & Diagnostics */}
      <GitSetupManager />

      {/* Git Push Guide & CLI Instructions */}
      <GitPushGuide />

      {/* GitHub OAuth Setup Guide */}
      <GitHubSetupGuide />

      {/* Global System Parameters */}
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-6">
        <h3 className="text-xl font-bold text-white flex items-center space-x-2">
          <Settings className="w-5 h-5 text-amber-400" />
          <span>Parâmetros Globais do Sistema</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
            <h4 className="text-sm font-bold text-white">Taxa de Comissão da Plataforma</h4>
            <p className="text-xs text-slate-400">Percentual retido automaticamente em cada assinatura, PPV ou gorjeta.</p>
            <div className="flex items-center space-x-3">
              <input type="number" defaultValue={10} className="w-24 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white font-mono" />
              <span className="text-sm text-slate-300">%</span>
            </div>
          </div>

          <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
            <h4 className="text-sm font-bold text-white">Tempo Máximo de Token LiveKit</h4>
            <p className="text-xs text-slate-400">Validade do JWT emitido pelo backend para autenticação na sala SFU.</p>
            <div className="flex items-center space-x-3">
              <input type="number" defaultValue={120} className="w-24 bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-sm text-white font-mono" />
              <span className="text-sm text-slate-300">minutos</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
