import { useState } from 'react';
import { Radio, Video, Users, Copy, Check, ShieldAlert, Sparkles, AlertTriangle, Key, Monitor } from 'lucide-react';
import { ChatMessage } from '../types';
import { MOCK_CHAT_MESSAGES } from '../data/auditData';

export function CreatorStudio() {
  const [isLive, setIsLive] = useState<boolean>(true);
  const [streamTitle, setStreamTitle] = useState<string>('Arquitetura de Alta Performance em Rust & LiveKit');
  const [copiedKey, setCopiedKey] = useState<boolean>(false);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(MOCK_CHAT_MESSAGES);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const streamKey = 'live_key_99x8877665544332211';
  const rtmpUrl = 'rtmp://live.nerlive.com.br/app';

  const handleCopyKey = () => {
    navigator.clipboard.writeText(streamKey);
    setCopiedKey(true);
    setTimeout(() => setCopiedKey(false), 3000);
  };

  const handleToggleLive = () => {
    setIsLive(!isLive);
    setSuccessMsg(isLive ? 'Transmissão encerrada com sucesso.' : 'Transmissão iniciada com sucesso via LiveKit SFU!');
    setTimeout(() => setSuccessMsg(null), 4000);
  };

  const handleDeleteMessage = (id: string) => {
    setChatMessages(chatMessages.filter(m => m.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {successMsg && (
        <div className="mb-6 bg-violet-500/20 border border-violet-500/30 text-violet-200 px-4 py-3 rounded-xl flex items-center space-x-3 shadow-lg">
          <Sparkles className="w-5 h-5 text-violet-400 flex-shrink-0" />
          <span className="text-sm font-medium">{successMsg}</span>
        </div>
      )}

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 text-xs font-mono font-semibold mb-2 border border-violet-500/30">
            <Radio className="w-4 h-4 text-violet-400" />
            <span>STUDIO DO CRIADOR — LIVEKIT SFU ENGINE</span>
          </div>
          <h1 className="text-3xl font-black text-white">Central de Transmissão</h1>
        </div>
        <button
          onClick={handleToggleLive}
          className={`px-6 py-3 rounded-xl font-bold text-sm shadow-lg transition-all flex items-center space-x-2 ${
            isLive
              ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/30'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
          }`}
        >
          <Radio className={`w-4 h-4 ${isLive ? 'animate-pulse' : ''}`} />
          <span>{isLive ? 'Encerrar Transmissão' : 'Iniciar Transmissão ao Vivo'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Stream Settings & Preview (2 Cols) */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <h3 className="text-lg font-bold text-white flex items-center space-x-2">
              <Monitor className="w-5 h-5 text-violet-400" />
              <span>Configurações do Stream</span>
            </h3>

            <div>
              <label className="block text-xs font-mono text-slate-400 mb-2">Título da Transmissão</label>
              <input
                type="text"
                value={streamTitle}
                onChange={(e) => setStreamTitle(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-violet-500"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-2">URL do Servidor RTMP (OBS Studio)</label>
                <input
                  type="text"
                  readOnly
                  value={rtmpUrl}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs font-mono text-slate-300"
                />
              </div>
              <div>
                <label className="block text-xs font-mono text-slate-400 mb-2">Chave de Transmissão (Stream Key)</label>
                <div className="flex items-center space-x-2">
                  <input
                    type="password"
                    readOnly
                    value={streamKey}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2 text-xs font-mono text-slate-300"
                  />
                  <button
                    onClick={handleCopyKey}
                    className="bg-slate-800 hover:bg-slate-700 p-2.5 rounded-xl text-white transition-colors"
                    title="Copiar Chave"
                  >
                    {copiedKey ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Stream Telemetry */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <div className="text-xs font-mono text-slate-400 mb-1">Espectadores</div>
              <div className="text-2xl font-black text-white">384</div>
              <div className="text-[10px] text-emerald-400 mt-1 font-mono">+12% vs última live</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <div className="text-xs font-mono text-slate-400 mb-1">Bitrate</div>
              <div className="text-2xl font-black text-white">6,450 kbps</div>
              <div className="text-[10px] text-emerald-400 mt-1 font-mono">1080p 60fps (Estável)</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <div className="text-xs font-mono text-slate-400 mb-1">Gorjetas (Sessão)</div>
              <div className="text-2xl font-black text-emerald-400">R$ 170,00</div>
              <div className="text-[10px] text-slate-400 mt-1 font-mono">5 gorjetas recebidas</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl shadow-xl">
              <div className="text-xs font-mono text-slate-400 mb-1">Latência SFU</div>
              <div className="text-2xl font-black text-cyan-400">180ms</div>
              <div className="text-[10px] text-cyan-300 mt-1 font-mono">LiveKit WebRTC</div>
            </div>
          </div>
        </div>

        {/* Live Chat Moderation Panel (1 Col) */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl flex flex-col h-[550px] shadow-2xl overflow-hidden">
          <div className="p-4 border-b border-slate-800 bg-slate-950/60 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Users className="w-4 h-4 text-violet-400" />
              <span>Moderação do Chat</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">{chatMessages.length} mensagens</span>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className="bg-slate-950/50 border border-slate-800/80 p-3 rounded-xl text-xs space-y-1 relative group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img src={msg.senderAvatar} alt={msg.senderName} className="w-5 h-5 rounded-full object-cover" />
                    <span className="font-bold text-white">{msg.senderName}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="text-[10px] text-slate-500 font-mono">{msg.timestamp}</span>
                    <button
                      onClick={() => handleDeleteMessage(msg.id)}
                      className="text-red-400 hover:text-red-300 opacity-0 group-hover:opacity-150 transition-opacity"
                      title="Excluir mensagem"
                    >
                      ✕
                    </button>
                  </div>
                </div>
                <p className="text-slate-300 pl-7">{msg.text}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
