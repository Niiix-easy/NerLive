import { useState } from 'react';
import { Webhook, Send, CheckCircle2, AlertTriangle, RefreshCw, Clock, Code, ShieldCheck } from 'lucide-react';

interface WebhookLogItem {
  id: string;
  event: string;
  status: 'success' | 'failed' | 'pending';
  statusCode: number;
  repository: string;
  timestamp: string;
  payload: any;
  error?: string;
}

export function WebhookInspector() {
  const [logs, setLogs] = useState<WebhookLogItem[]>([
    {
      id: 'wh-001',
      event: 'push',
      status: 'success',
      statusCode: 200,
      repository: 'Niiix-easy/NerLive',
      timestamp: '17:28:10',
      payload: {
        ref: 'refs/heads/main',
        before: '1daa580',
        after: '974a84b',
        commits: [{ id: '974a84b', message: 'feat: Add useGitHubStatus hook and setup guide' }]
      }
    },
    {
      id: 'wh-002',
      event: 'ping',
      status: 'success',
      statusCode: 200,
      repository: 'Niiix-easy/NerLive',
      timestamp: '17:15:02',
      payload: {
        zen: 'Practicality beats purity.',
        hook_id: 42891023,
        repository: { full_name: 'Niiix-easy/NerLive' }
      }
    },
    {
      id: 'wh-003',
      event: 'pull_request',
      status: 'failed',
      statusCode: 401,
      repository: 'Niiix-easy/NerLive',
      timestamp: '17:02:45',
      payload: { action: 'opened', number: 4, title: 'Refactor LiveKit room' },
      error: 'Invalid webhook signature (HMAC SHA-256 verification failed).'
    }
  ]);

  const [selectedLog, setSelectedLog] = useState<WebhookLogItem | null>(logs[0]);
  const [simulating, setSimulating] = useState<boolean>(false);

  const handleSimulateWebhook = (eventType: 'push' | 'pull_request' | 'workflow_run') => {
    setSimulating(true);

    setTimeout(() => {
      const isFailed = eventType === 'pull_request';
      const newLog: WebhookLogItem = {
        id: `wh-${Date.now().toString().slice(-4)}`,
        event: eventType,
        status: isFailed ? 'failed' : 'success',
        statusCode: isFailed ? 401 : 200,
        repository: 'Niiix-easy/NerLive',
        timestamp: new Date().toLocaleTimeString(),
        payload: {
          action: eventType === 'push' ? 'synchronize' : eventType === 'pull_request' ? 'opened' : 'completed',
          event_type: eventType,
          sender: { login: 'Niiix-easy' },
          repository: { full_name: 'Niiix-easy/NerLive' },
          timestamp: new Date().toISOString()
        },
        error: isFailed ? 'Signature mismatch: X-Hub-Signature-256 header missing or invalid token.' : undefined
      };

      setLogs([newLog, ...logs]);
      setSelectedLog(newLog);
      setSimulating(false);

      // Dispatch event for WebhookHealthMonitor toast alert
      if (isFailed) {
        window.dispatchEvent(new CustomEvent('nerlive_webhook_event', { detail: newLog }));
      }
    }, 800);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-cyan-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Webhook className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">WebhookInspector & Log de Sincronização</h2>
            <p className="text-xs text-slate-400">Inspecione payloads recebidos do GitHub e analise o status de processamento de falhas.</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleSimulateWebhook('push')}
            disabled={simulating}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors shadow-lg shadow-cyan-600/20 disabled:opacity-50"
          >
            <Send className={`w-3.5 h-3.5 ${simulating ? 'animate-pulse' : ''}`} />
            <span>Simular Push Webhook</span>
          </button>
          <button
            onClick={() => handleSimulateWebhook('pull_request')}
            disabled={simulating}
            className="px-4 py-2 bg-red-600/20 border border-red-500/30 hover:bg-red-600/30 text-red-300 text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors"
          >
            <span>Simular Falha (Auth)</span>
          </button>
        </div>
      </div>

      {/* Grid Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Logs List */}
        <div className="space-y-3 max-h-[500px] overflow-y-auto pr-2">
          <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Eventos Recebidos ({logs.length})</h3>
          {logs.map((log) => (
            <div
              key={log.id}
              onClick={() => setSelectedLog(log)}
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedLog?.id === log.id
                  ? 'bg-cyan-950/40 border-cyan-500 shadow-md'
                  : 'bg-slate-950 border-slate-800 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className={`w-2 h-2 rounded-full ${log.status === 'success' ? 'bg-emerald-400' : 'bg-red-400'}`} />
                  <span className="text-xs font-bold text-white uppercase font-mono">{log.event}</span>
                </div>
                <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                  log.status === 'success' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/20 text-red-300 border border-red-500/30'
                }`}>
                  HTTP {log.statusCode}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>{log.repository}</span>
                <span>{log.timestamp}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Payload Detail Viewer */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-2xl p-6 flex flex-col justify-between space-y-4">
          {selectedLog ? (
            <>
              <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-mono text-cyan-400 uppercase font-bold">ID: {selectedLog.id}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold ${
                      selectedLog.status === 'success' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'
                    }`}>
                      {selectedLog.status === 'success' ? 'Processado com Sucesso' : 'Falha no Processamento'}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white mt-1 capitalize">Evento: {selectedLog.event}</h3>
                </div>
                <span className="text-xs text-slate-400 font-mono">{selectedLog.timestamp}</span>
              </div>

              {selectedLog.error && (
                <div className="bg-red-950/40 border border-red-500/30 text-red-200 p-3.5 rounded-xl text-xs flex items-center space-x-3">
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span><strong>Erro Detectado:</strong> {selectedLog.error}</span>
                </div>
              )}

              <div className="space-y-2 flex-1">
                <div className="text-xs font-mono text-slate-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <Code className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Payload JSON do Webhook</span>
                </div>
                <pre className="bg-slate-900 border border-slate-800 p-4 rounded-xl text-xs font-mono text-cyan-300 overflow-x-auto max-h-72 leading-relaxed">
                  {JSON.stringify(selectedLog.payload, null, 2)}
                </pre>
              </div>

              <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400 font-mono">
                <span>Repositório: {selectedLog.repository}</span>
                <span className="text-emerald-400">Listener Ativo (/api/webhooks/github)</span>
              </div>
            </>
          ) : (
            <div className="flex items-center justify-center h-full text-slate-500 text-sm font-mono">
              Selecione um evento para inspecionar o payload.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
