import { useState } from 'react';
import { Terminal, Filter, Search, CheckCircle2, AlertTriangle, ShieldAlert, RefreshCw, Database } from 'lucide-react';

interface SystemLogItem {
  id: string;
  timestamp: string;
  type: 'auth' | 'database' | 'storage' | 'edge_function' | 'webhook';
  status: 'success' | 'error' | 'warning';
  message: string;
  details?: string;
}

export function SystemLogs() {
  const [logs, setLogs] = useState<SystemLogItem[]>([
    {
      id: 'log-101',
      timestamp: '2026-11-12 17:51:10',
      type: 'auth',
      status: 'success',
      message: 'User sign-in via GitHub OAuth successful (uid: u_88921)',
      details: 'POST /auth/v1/token?grant_type=authorization_code (HTTP 200)'
    },
    {
      id: 'log-102',
      timestamp: '2026-11-12 17:48:22',
      type: 'database',
      status: 'success',
      message: 'Executed RLS policy check on table financial_ledger',
      details: 'SELECT * FROM financial_ledger WHERE user_id = auth.uid()'
    },
    {
      id: 'log-103',
      timestamp: '2026-11-12 17:45:00',
      type: 'webhook',
      status: 'error',
      message: 'GitHub Webhook signature verification failed (HMAC mismatch)',
      details: 'X-Hub-Signature-256 header missing or invalid secret token.'
    },
    {
      id: 'log-104',
      timestamp: '2026-11-12 17:30:15',
      type: 'edge_function',
      status: 'success',
      message: 'LiveKit token generation edge function executed',
      details: 'POST /functions/v1/livekit-token (Duration: 42ms)'
    },
    {
      id: 'log-105',
      timestamp: '2026-11-12 17:10:04',
      type: 'storage',
      status: 'warning',
      message: 'Large video upload detected in bucket live-recordings',
      details: 'File size: 1.2 GB. Multipart upload initiated.'
    }
  ]);

  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredLogs = logs.filter(log => {
    const matchesType = filterType === 'all' || log.type === filterType;
    const matchesStatus = filterStatus === 'all' || log.status === filterStatus;
    const matchesSearch = log.message.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          (log.details && log.details.toLowerCase().includes(searchQuery.toLowerCase()));
    return matchesType && matchesStatus && matchesSearch;
  });

  const handleSimulateLog = () => {
    const types: ('auth' | 'database' | 'storage' | 'edge_function' | 'webhook')[] = ['auth', 'database', 'storage', 'edge_function', 'webhook'];
    const statuses: ('success' | 'error' | 'warning')[] = ['success', 'error', 'warning'];
    const randomType = types[Math.floor(Math.random() * types.length)];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];

    const newLog: SystemLogItem = {
      id: `log-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toLocaleString(),
      type: randomType,
      status: randomStatus,
      message: `Simulated event for ${randomType} operation (${randomStatus})`,
      details: `Triggered via Supabase Realtime Log Streaming API at ${new Date().toISOString()}`
    };

    setLogs([newLog, ...logs]);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-cyan-600/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Terminal className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">System Logs (Supabase Audit Stream)</h2>
            <p className="text-xs text-slate-400">Monitoramento em tempo real de eventos de sucesso, aviso e erro do banco e autenticação.</p>
          </div>
        </div>

        <button
          onClick={handleSimulateLog}
          className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors shadow-lg shadow-cyan-600/30"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Simular Novo Log</span>
        </button>
      </div>

      {/* Filters & Search */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar nos logs..."
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-10 pr-4 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono"
          />
        </div>

        <div>
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono cursor-pointer"
          >
            <option value="all">Todos os Tipos de Operação</option>
            <option value="auth">Auth (Autenticação)</option>
            <option value="database">Database (PostgreSQL)</option>
            <option value="storage">Storage (Mídia)</option>
            <option value="edge_function">Edge Functions</option>
            <option value="webhook">Webhooks</option>
          </select>
        </div>

        <div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-500 font-mono cursor-pointer"
          >
            <option value="all">Todos os Status (Success/Error/Warning)</option>
            <option value="success">Sucesso (Success)</option>
            <option value="error">Erro (Error)</option>
            <option value="warning">Aviso (Warning)</option>
          </select>
        </div>
      </div>

      {/* Logs Table */}
      <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] font-mono text-slate-400 uppercase">
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Tipo</th>
                <th className="py-3 px-4">Mensagem & Detalhes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-xs">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-slate-900/40 transition-colors font-mono">
                  <td className="py-3.5 px-4">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase inline-flex items-center space-x-1 ${
                      log.status === 'success'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/35'
                        : log.status === 'error'
                        ? 'bg-red-500/20 text-red-300 border border-red-500/35'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/35'
                    }`}>
                      {log.status === 'success' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                      {log.status === 'error' && <ShieldAlert className="w-3 h-3 text-red-400" />}
                      {log.status === 'warning' && <AlertTriangle className="w-3 h-3 text-amber-400" />}
                      <span>{log.status}</span>
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-slate-400">{log.timestamp}</td>
                  <td className="py-3.5 px-4 text-cyan-300 uppercase font-bold text-[11px]">{log.type}</td>
                  <td className="py-3.5 px-4 space-y-0.5">
                    <div className="text-white font-sans font-medium">{log.message}</div>
                    {log.details && <div className="text-[11px] text-slate-400">{log.details}</div>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
