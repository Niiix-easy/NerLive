import { Database, ShieldCheck, Code } from 'lucide-react';

export function DatabaseSchemaViewer() {
  const schemaSQL = `-- ====================================================================
-- NERLIVE — DATABASE SCHEMA & RLS POLICIES (POSTGRESQL / SUPABASE)
-- ====================================================================

-- 1. PROFILES
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    role TEXT CHECK (role IN ('viewer', 'creator', 'admin')) DEFAULT 'viewer',
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. CREATORS
CREATE TABLE creators (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
    handle TEXT UNIQUE NOT NULL,
    bio TEXT,
    category TEXT,
    banner_url TEXT,
    subscribers_count INT DEFAULT 0,
    monthly_subscription_price INT DEFAULT 0, -- em centavos inteiros
    is_live BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. EVENTS
CREATE TABLE events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    creator_id UUID REFERENCES creators(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    category TEXT,
    thumbnail_url TEXT,
    is_live BOOLEAN DEFAULT FALSE,
    is_pay_per_view BOOLEAN DEFAULT FALSE,
    price INT DEFAULT 0, -- em centavos inteiros
    stream_key TEXT,
    viewers_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 4. FINANCIAL LEDGER (Imutável)
CREATE TABLE financial_ledger (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES profiles(id),
    creator_id UUID REFERENCES creators(id),
    type TEXT CHECK (type IN ('subscription', 'pay_per_view', 'tip', 'gift', 'payout', 'platform_fee')),
    description TEXT NOT NULL,
    amount INT NOT NULL, -- SEMPRE em centavos inteiros (ex: R$ 50,00 = 5000)
    status TEXT CHECK (status IN ('completed', 'pending', 'refunded')) DEFAULT 'completed',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- RLS POLICIES
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE financial_ledger ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles are viewable by everyone" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can view their own ledger transactions" ON financial_ledger FOR SELECT USING (auth.uid() = user_id);
`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      <div className="flex items-center justify-between mb-8">
        <div>
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 text-xs font-mono font-semibold mb-2 border border-cyan-500/30">
            <Database className="w-4 h-4 text-cyan-400" />
            <span>POSTGRESQL & SUPABASE SCHEMA</span>
          </div>
          <h1 className="text-3xl font-black text-white">Modelagem de Dados Oficial</h1>
        </div>
      </div>

      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-sm text-slate-300">
            <Code className="w-4 h-4 text-cyan-400" />
            <span>Regra Financeira: Valores monetários armazenados estritamente em centavos inteiros (Int) para evitar imprecisões de ponto flutuante.</span>
          </div>
          <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            PostgreSQL 16 + RLS
          </span>
        </div>

        <pre className="bg-slate-950 p-6 rounded-xl border border-slate-800 font-mono text-xs text-cyan-300 overflow-x-auto leading-relaxed">
          {schemaSQL}
        </pre>
      </div>
    </div>
  );
}
