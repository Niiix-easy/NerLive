import { useState } from 'react';
import { ShieldCheck, AlertTriangle, CheckCircle2, FileText, Server, Cpu, Database, Lock, Layers, Code, GitBranch, ArrowRight, Download, Printer } from 'lucide-react';
import { AUDIT_SECTIONS } from '../data/auditData';

export function AuditReportView() {
  const [selectedSection, setSelectedSection] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'sections' | 'matrix' | 'architecture'>('sections');

  const handleExportPDF = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100">
      {/* Hero Banner */}
      <div className="bg-gradient-to-r from-violet-900/60 via-slate-900 to-indigo-950/80 border border-violet-500/30 rounded-2xl p-8 mb-8 shadow-2xl backdrop-blur-md">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-violet-500/20 text-violet-300 text-xs font-mono font-semibold mb-4 border border-violet-500/30">
              <ShieldCheck className="w-4 h-4" />
              <span>PROMPT MESTRE — AUDITORIA TÉCNICA OFICIAL</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black tracking-tight text-white mb-3">
              Plataforma NerLive — Arquitetura & Open Source Audit
            </h1>
            <p className="text-slate-300 max-w-2xl text-sm sm:text-base leading-relaxed">
              Auditoria multidisciplinar completa avaliando os repositórios <strong className="text-violet-300">Revel (Django)</strong>, <strong className="text-indigo-300">PPV Stream Rust</strong> e <strong className="text-pink-300">LiveKit (SFU)</strong> para integração segura, escalável e de alta performance na NerLive.
            </p>
          </div>
          <div className="flex flex-wrap gap-3 w-full md:w-auto">
            <button
              onClick={() => setActiveTab('sections')}
              className={`px-4 py-2.5 rounded-xl font-medium text-sm transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'sections'
                  ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/40'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span>Relatório de Fases</span>
            </button>
            <button
              onClick={() => setActiveTab('matrix')}
              className={`px-4 py-2.5 rounded-xl font-medium text-sm transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'matrix'
                  ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/40'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Matriz de Licenças</span>
            </button>
            <button
              onClick={() => setActiveTab('architecture')}
              className={`px-4 py-2.5 rounded-xl font-medium text-sm transition-all flex items-center justify-center space-x-2 ${
                activeTab === 'architecture'
                  ? 'bg-violet-600 text-white shadow-lg shadow-violet-600/40'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Server className="w-4 h-4" />
              <span>Arquitetura Final</span>
            </button>
            <button
              onClick={handleExportPDF}
              className="px-4 py-2.5 rounded-xl font-bold text-sm bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/30 transition-all flex items-center justify-center space-x-2"
              title="Baixar Relatório em PDF"
            >
              <Printer className="w-4 h-4" />
              <span>Exportar PDF / Imprimir</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Switcher */}
      {activeTab === 'sections' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Section List */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-400 px-1">
              Seções da Auditoria (1 a 8)
            </h3>
            {AUDIT_SECTIONS.map((sec, index) => (
              <button
                key={index}
                onClick={() => setSelectedSection(index)}
                className={`w-full text-left p-4 rounded-xl transition-all border flex items-start justify-between group ${
                  selectedSection === index
                    ? 'bg-violet-950/50 border-violet-500 shadow-lg shadow-violet-950/50'
                    : 'bg-slate-900/60 border-slate-800 hover:bg-slate-800/80'
                }`}
              >
                <div>
                  <div className="flex items-center space-x-2 mb-1">
                    <span className="text-xs font-mono text-violet-400 font-semibold">{sec.category}</span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        sec.riskLevel === 'CRÍTICO'
                          ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                          : sec.riskLevel === 'ALTO'
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                          : sec.riskLevel === 'MÉDIO'
                          ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      RISCO: {sec.riskLevel}
                    </span>
                  </div>
                  <h4 className="text-sm font-semibold text-white group-hover:text-violet-300 transition-colors">
                    {sec.title}
                  </h4>
                </div>
                <ArrowRight className={`w-4 h-4 mt-2 transition-transform ${selectedSection === index ? 'text-violet-400 translate-x-1' : 'text-slate-600'}`} />
              </button>
            ))}
          </div>

          {/* Section Detail Card */}
          <div className="lg:col-span-2 bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
              <div>
                <span className="text-xs font-mono text-violet-400 uppercase tracking-wider">
                  {AUDIT_SECTIONS[selectedSection].category}
                </span>
                <h2 className="text-2xl font-bold text-white mt-1">
                  {AUDIT_SECTIONS[selectedSection].title}
                </h2>
              </div>
              <span
                className={`text-xs px-3 py-1 rounded-full font-bold uppercase tracking-wider ${
                  AUDIT_SECTIONS[selectedSection].riskLevel === 'CRÍTICO'
                    ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                    : AUDIT_SECTIONS[selectedSection].riskLevel === 'ALTO'
                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                    : AUDIT_SECTIONS[selectedSection].riskLevel === 'MÉDIO'
                    ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                Risco: {AUDIT_SECTIONS[selectedSection].riskLevel}
              </span>
            </div>

            <div className="mb-6">
              <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Resumo da Análise</h4>
              <p className="text-slate-200 text-base leading-relaxed bg-slate-950/40 p-4 rounded-xl border border-slate-800/80">
                {AUDIT_SECTIONS[selectedSection].summary}
              </p>
            </div>

            <div>
              <h4 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">Diretrizes & Recomendações Técnicas</h4>
              <ul className="space-y-3">
                {AUDIT_SECTIONS[selectedSection].details.map((detail, idx) => (
                  <li key={idx} className="flex items-start space-x-3 text-slate-300 bg-slate-950/20 p-3.5 rounded-xl border border-slate-800/50">
                    <CheckCircle2 className="w-5 h-5 text-violet-400 flex-shrink-0 mt-0.5" />
                    <span className="text-sm leading-relaxed">{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mt-8 pt-6 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
              <span className="font-mono">Status: Aprovado para Fase de Implementação Controlada</span>
              <span className="font-mono text-violet-400">NerLive Engineering Team</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'matrix' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">Matriz de Licenças e Reutilização Open Source</h2>
            <p className="text-slate-400 text-sm">
              Avaliação jurídica e técnica para reaproveitamento dos projetos Revel, PPV Stream Rust e LiveKit na NerLive.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs font-mono text-slate-400 uppercase">
                  <th className="py-3 px-4">Projeto / Componente</th>
                  <th className="py-3 px-4">Licença</th>
                  <th className="py-3 px-4">Uso Comercial</th>
                  <th className="py-3 px-4">Obrigações</th>
                  <th className="py-3 px-4">Decisão</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-sm">
                <tr>
                  <td className="py-4 px-4 font-semibold text-white">LiveKit Server & SDKs</td>
                  <td className="py-4 px-4 text-slate-300">Apache 2.0</td>
                  <td className="py-4 px-4 text-emerald-400 font-medium">Permitido</td>
                  <td className="py-4 px-4 text-slate-400">Manter copyright e aviso de modificação.</td>
                  <td className="py-4 px-4"><span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">A. Reutilizável</span></td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-semibold text-white">Revel Backend (Django)</td>
                  <td className="py-4 px-4 text-slate-300">MIT</td>
                  <td className="py-4 px-4 text-emerald-400 font-medium">Permitido</td>
                  <td className="py-4 px-4 text-slate-400">Inclusão da licença original no repositório.</td>
                  <td className="py-4 px-4"><span className="px-2.5 py-1 rounded-full text-xs font-bold bg-violet-500/20 text-violet-300 border border-violet-500/30">B. Adaptação Lógica</span></td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-semibold text-white">PPV Stream Rust (Axum/FFmpeg)</td>
                  <td className="py-4 px-4 text-slate-300">MIT</td>
                  <td className="py-4 px-4 text-emerald-400 font-medium">Permitido</td>
                  <td className="py-4 px-4 text-slate-400">Atribuição de autoria.</td>
                  <td className="py-4 px-4"><span className="px-2.5 py-1 rounded-full text-xs font-bold bg-violet-500/20 text-violet-300 border border-violet-500/30">B. Adaptação Mídia</span></td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-semibold text-white">PostgreSQL & Supabase Stack</td>
                  <td className="py-4 px-4 text-slate-300">PostgreSQL / Apache</td>
                  <td className="py-4 px-4 text-emerald-400 font-medium">Permitido</td>
                  <td className="py-4 px-4 text-slate-400">Nenhuma restrição de distribuição.</td>
                  <td className="py-4 px-4"><span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">A. Reutilizável</span></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {activeTab === 'architecture' && (
        <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">Arquitetura Oficial da NerLive</h2>
            <p className="text-slate-400 text-sm">
              Separação limpa entre interface Lovable/React, backend de negócios Supabase/Node, motor de streaming SFU LiveKit e processamento de mídia.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-slate-950/60 border border-slate-800 p-6 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400 mb-4">
                <Code className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Frontend (Lovable / React)</h3>
              <ul className="space-y-2 text-sm text-slate-300">
                <li>• Painel do Criador & Studio</li>
                <li>• Portal de Espectadores & PPV</li>
                <li>• Chat em Tempo Real com WebSocket</li>
                <li>• Player HLS / LiveKit WebRTC</li>
              </ul>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 p-6 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 mb-4">
                <Database className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Backend & Banco (Supabase)</h3>
              <ul className="space-y-2 text-sm text-slate-300">
                <li>• PostgreSQL com RLS Avançado</li>
                <li>• Ledger Financeiro em Centavos</li>
                <li>• Geração de Tokens LiveKit JWT</li>
                <li>• Webhooks Idempotentes (Asaas/MP)</li>
              </ul>
            </div>

            <div className="bg-slate-950/60 border border-slate-800 p-6 rounded-xl">
              <div className="w-10 h-10 rounded-lg bg-pink-600/20 border border-pink-500/30 flex items-center justify-center text-pink-400 mb-4">
                <Server className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Streaming & Mídia (VPS/S3)</h3>
              <ul className="space-y-2 text-sm text-slate-300">
                <li>• LiveKit SFU Server (WebRTC)</li>
                <li>• Storage S3 Compatível p/ Gravações</li>
                <li>• FFmpeg para Transcode & HLS</li>
                <li>• CDN de Baixa Latência</li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
