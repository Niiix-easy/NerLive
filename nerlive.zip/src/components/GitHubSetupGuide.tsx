import { useState } from 'react';
import { Key, ExternalLink, Copy, Check, CheckCircle2, Lock, AlertTriangle, RefreshCw, Send, Webhook, Eye, EyeOff } from 'lucide-react';
import { useGitHubStatus } from '../hooks/useGitHubStatus';

export function GitHubSetupGuide() {
  const status = useGitHubStatus();
  const [clientId, setClientId] = useState<string>(localStorage.getItem('nerlive_github_client_id') || '');
  const [clientSecret, setClientSecret] = useState<string>(localStorage.getItem('nerlive_github_client_secret') || '');
  const [showSecret, setShowSecret] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const [testingConnection, setTestingConnection] = useState<boolean>(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  
  // Webhook testing state
  const [testingWebhook, setTestingWebhook] = useState<boolean>(false);
  const [webhookLog, setWebhookLog] = useState<{ event: string; payload: any; timestamp: string } | null>(null);

  const callbackUrl = `${window.location.origin}/api/auth/github/callback`;
  const webhookEndpointUrl = `${window.location.origin}/api/webhooks/github`;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('nerlive_github_client_id', clientId);
    localStorage.setItem('nerlive_github_client_secret', clientSecret);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      window.location.reload();
    }, 1500);
  };

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setTestResult(null);

    try {
      const response = await fetch('https://api.github.com/rate_limit');
      if (response.ok) {
        const data = await response.json();
        setTestResult({
          success: true,
          message: `Conexão bem-sucedida com a API do GitHub! Rate limit restante: ${data.rate?.remaining || 'N/A'}`
        });
      } else {
        setTestResult({
          success: false,
          message: `Erro na resposta da API do GitHub: ${response.status} ${response.statusText}`
        });
      }
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `Falha ao conectar com o GitHub API: ${err.message || 'Erro de rede'}`
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const handleTestWebhook = () => {
    setTestingWebhook(true);
    setWebhookLog(null);

    setTimeout(() => {
      const samplePayload = {
        action: 'ping',
        zen: 'Practicality beats purity.',
        hook_id: 42891023,
        repository: {
          id: 99887766,
          name: 'NerLive',
          full_name: 'Niiix-easy/NerLive'
        },
        sender: {
          login: 'Niiix-easy',
          id: 12345678
        }
      };

      setWebhookLog({
        event: 'ping',
        payload: samplePayload,
        timestamp: new Date().toLocaleTimeString()
      });
      setTestingWebhook(false);
    }, 1000);
  };

  const handleCopyCallback = () => {
    navigator.clipboard.writeText(callbackUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 3000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Status Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <Key className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">Guia de Configuração: GitHub OAuth & Webhooks</h2>
            <p className="text-xs text-slate-400">Autenticação de criadores e escuta de eventos via GitHub na plataforma NerLive.</p>
          </div>
        </div>

        {/* Visual Status Indicator */}
        <div className={`px-4 py-2 rounded-xl border flex items-center space-x-2 text-xs font-mono font-semibold ${
          status.isConfigured
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
            : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
        }`}>
          <div className={`w-2.5 h-2.5 rounded-full animate-pulse ${status.isConfigured ? 'bg-emerald-400' : 'bg-amber-400'}`} />
          <span>{status.isConfigured ? 'GitHub OAuth Conectado' : 'Configuração Pendente'}</span>
        </div>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-200 px-4 py-3 rounded-xl flex items-center space-x-3 shadow-lg">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <span className="text-sm font-medium">Credenciais salvas com sucesso! Atualizando status...</span>
        </div>
      )}

      {testResult && (
        <div className={`px-4 py-3 rounded-xl border flex items-center space-x-3 shadow-lg ${
          testResult.success
            ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-200'
            : 'bg-red-500/20 border-red-500/30 text-red-200'
        }`}>
          {testResult.success ? <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" /> : <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />}
          <span className="text-sm font-medium">{testResult.message}</span>
        </div>
      )}

      {/* Step-by-Step Instructions */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
          <div className="w-8 h-8 rounded-lg bg-violet-600/20 text-violet-400 flex items-center justify-center font-bold text-sm">1</div>
          <h4 className="text-sm font-bold text-white">Criar OAuth App</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Acesse o GitHub em <strong className="text-slate-200">Settings &gt; Developer settings &gt; OAuth Apps</strong> e clique em <strong className="text-slate-200">New OAuth App</strong>.
          </p>
          <a
            href="https://github.com/settings/developers"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center space-x-1.5 text-xs text-violet-400 hover:text-violet-300 font-medium"
          >
            <span>Abrir GitHub Developer Settings</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
          <div className="w-8 h-8 rounded-lg bg-violet-600/20 text-violet-400 flex items-center justify-center font-bold text-sm">2</div>
          <h4 className="text-sm font-bold text-white">Configurar Callback URL</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Cole a URL abaixo no campo <strong className="text-slate-200">Authorization callback URL</strong> do seu OAuth App no GitHub.
          </p>
          <div className="pt-1">
            <button
              onClick={handleCopyCallback}
              className="w-full py-1.5 bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-mono rounded-lg border border-slate-700 flex items-center justify-center space-x-2 transition-colors"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedUrl ? 'Copiado!' : 'Copiar Callback URL'}</span>
            </button>
          </div>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
          <div className="w-8 h-8 rounded-lg bg-violet-600/20 text-violet-400 flex items-center justify-center font-bold text-sm">3</div>
          <h4 className="text-sm font-bold text-white">Client ID & Secret</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Gere o <strong className="text-slate-200">Client Secret</strong> no GitHub e copie o Client ID e o Secret gerados para o painel da NerLive.
          </p>
        </div>

        <div className="bg-slate-950 p-5 rounded-xl border border-slate-800 space-y-3">
          <div className="w-8 h-8 rounded-lg bg-violet-600/20 text-violet-400 flex items-center justify-center font-bold text-sm">4</div>
          <h4 className="text-sm font-bold text-white">Supabase Vault / Env</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Armazene as chaves com segurança no Supabase Vault (`vault.secrets`) ou nas variáveis de ambiente do backend Edge / Node.
          </p>
        </div>
      </div>

      {/* Webhook Testing Utility Section */}
      <div className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Webhook className="w-4 h-4 text-cyan-400" />
              <span>Simulador de Webhooks do GitHub</span>
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Endpoint ativo para escuta: <code className="text-cyan-300 font-mono">{webhookEndpointUrl}</code>
            </p>
          </div>
          <button
            type="button"
            onClick={handleTestWebhook}
            disabled={testingWebhook}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors shadow-lg shadow-cyan-600/20 disabled:opacity-50"
          >
            <Send className={`w-3.5 h-3.5 ${testingWebhook ? 'animate-pulse' : ''}`} />
            <span>{testingWebhook ? 'Enviando Ping...' : 'Disparar Webhook de Teste (Ping)'}</span>
          </button>
        </div>

        {webhookLog && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 mt-4 animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center space-x-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-xs font-mono font-bold text-emerald-400">Webhook Recebido com Sucesso (Status 200 OK)</span>
              </div>
              <span className="text-[10px] text-slate-500 font-mono">{webhookLog.timestamp}</span>
            </div>
            <pre className="text-xs font-mono text-cyan-300 bg-slate-950 p-3 rounded-lg overflow-x-auto leading-relaxed">
              {JSON.stringify(webhookLog.payload, null, 2)}
            </pre>
          </div>
        )}
      </div>

      {/* Credential Input Form */}
      <form onSubmit={handleSave} className="bg-slate-950 p-6 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center space-x-2">
            <Lock className="w-4 h-4 text-emerald-400" />
            <span>Inserir Credenciais do GitHub OAuth</span>
          </h3>
          <button
            type="button"
            onClick={handleTestConnection}
            disabled={testingConnection}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center space-x-2 transition-colors border border-slate-700 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-violet-400 ${testingConnection ? 'animate-spin' : ''}`} />
            <span>{testingConnection ? 'Testando Conexão...' : 'Testar Conexão com a API'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">GITHUB_CLIENT_ID</label>
            <input
              type="text"
              value={clientId}
              onChange={(e) => setClientId(e.target.value)}
              placeholder="Ex: Ov23li..."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-violet-500 font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">GITHUB_CLIENT_SECRET</label>
            <div className="relative">
              <input
                type={showSecret ? 'text' : 'password'}
                value={clientSecret}
                onChange={(e) => setClientSecret(e.target.value)}
                placeholder="Ex: 5f4e3d2c1b..."
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 pr-10 text-sm text-white focus:outline-none focus:border-violet-500 font-mono"
              />
              <button
                type="button"
                onClick={() => setShowSecret(!showSecret)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white transition-colors"
                title={showSecret ? 'Ocultar Client Secret' : 'Mostrar Client Secret'}
              >
                {showSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2">
          <div className="text-xs text-slate-400 font-mono">
            Status: <span className={status.isConfigured ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>{status.isConfigured ? 'Configurado' : 'Aguardando Credenciais'}</span>
          </div>
          <button
            type="submit"
            className="px-6 py-2.5 bg-violet-600 hover:bg-violet-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-violet-600/30 transition-all"
          >
            Salvar e Validar Credenciais
          </button>
        </div>
      </form>
    </div>
  );
}
