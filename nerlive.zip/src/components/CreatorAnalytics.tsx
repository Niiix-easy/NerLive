import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar, CartesianGrid } from 'recharts';
import { Users, DollarSign, TrendingUp, MessageSquare, Activity } from 'lucide-react';

const viewerData = [
  { time: '10:00', viewers: 120, engagement: 45 },
  { time: '10:10', viewers: 240, engagement: 89 },
  { time: '10:20', viewers: 380, engagement: 140 },
  { time: '10:30', viewers: 350, engagement: 125 },
  { time: '10:40', viewers: 420, engagement: 195 },
  { time: '10:50', viewers: 510, engagement: 230 },
  { time: '11:00', viewers: 484, engagement: 210 },
];

const revenueData = [
  { day: 'Seg', subscriptions: 1500, tips: 300, ppv: 800 },
  { day: 'Ter', subscriptions: 1800, tips: 450, ppv: 1200 },
  { day: 'Qua', subscriptions: 2200, tips: 600, ppv: 950 },
  { day: 'Qui', subscriptions: 2000, tips: 500, ppv: 1500 },
  { day: 'Sex', subscriptions: 3100, tips: 900, ppv: 2400 },
  { day: 'Sáb', subscriptions: 3800, tips: 1250, ppv: 3100 },
  { day: 'Dom', subscriptions: 3400, tips: 1100, ppv: 2800 },
];

export function CreatorAnalytics() {
  return (
    <div className="space-y-6 text-slate-100">
      {/* Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Concurrent Viewers Chart */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <Users className="w-4 h-4 text-violet-400" />
                <span>Espectadores Simultâneos & Engajamento</span>
              </h3>
              <p className="text-xs text-slate-400">Pico de 510 espectadores na transmissão atual.</p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
              Ao Vivo (LiveKit)
            </span>
          </div>

          <div className="h-64 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={viewerData}>
                <defs>
                  <linearGradient id="colorViewers" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                />
                <Area type="monotone" dataKey="viewers" stroke="#8b5cf6" strokeWidth={2} fillOpacity={1} fill="url(#colorViewers)" name="Espectadores" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Estimated Revenue Chart */}
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white flex items-center space-x-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Receita Estimada por Categoria</span>
              </h3>
              <p className="text-xs text-slate-400">Assinaturas, Gorjetas e Pay-Per-View nos últimos 7 dias.</p>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">
              Total: R$ 25.450
            </span>
          </div>

          <div className="h-64 w-full pt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="day" stroke="#64748b" fontSize={11} />
                <YAxis stroke="#64748b" fontSize={11} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', color: '#fff', fontSize: '12px' }}
                />
                <Bar dataKey="subscriptions" fill="#8b5cf6" name="Assinaturas" radius={[4, 4, 0, 0]} />
                <Bar dataKey="ppv" fill="#ec4899" name="Pay-Per-View" radius={[4, 4, 0, 0]} />
                <Bar dataKey="tips" fill="#10b981" name="Gorjetas" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
