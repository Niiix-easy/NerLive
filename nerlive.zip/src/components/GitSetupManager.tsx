import { useState } from 'react';
import { GitBranch, Terminal, Copy, Check, ExternalLink, ShieldCheck, CheckCircle2, Lock, Key, RefreshCw, AlertTriangle, TerminalSquare } from 'lucide-react';

export function GitSetupManager() {
  const [repoUrl, setRepoUrl] = useState<string>(localStorage.getItem('nerlive_git_repo_url') || 'https://github.com/Niiix-easy/NerLive.git');
  const [sshKey, setSshKey] = useState<string>(localStorage.getItem('nerlive_git_ssh_key') || '');
  const [showSshKey, setShowSshKey] = useState<boolean>(false);
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);
  
  // Diagnostic state
  const [diagnosing, setDiagnosing] = useState<boolean>(false);
  const [diagnosticResult, setDiagnosticResult] = useState<{ success: boolean; message: string; logs: string[] } | null>(null);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('nerlive_git_repo_url', repoUrl);
    localStorage.setItem('nerlive_git_ssh_key', sshKey);
    localStorage.setItem('nerlive_last_sync_status', 'Configurações salvas');
    localStorage.setItem('nerlive_last_sync_time', new Date().toLocaleString());
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleRunDiagnostic = async () => {
    setDiagnosing(true);
    setDiagnosticResult(null);

    const logs: string[] = [
      `[INFO] Iniciando teste de diagnóstico de conectividade Git...`,
      `[INFO] Verificando URL remota: ${repoUrl}`,
      `[INFO] Testando resolução DNS e handshake HTTPS para github.com...`
    ];

    try {
      // Test GitHub API repo existence check
      const apiEndpoint = repoUrl
        .replace('https://github.com/', 'https://api.github.com/repos/')
        .replace('.git', '');

      const response = await fetch(apiEndpoint);
      
      if (response.ok) {
        const data = await response.json();
        logs.push(`[SUCCESS] Conexão HTTP 200 OK com o repositório ${data.full_name}`);
        logs.push(`[SUCCESS] Visibilidade do repositório: ${data.private ? 'Privado (Requer Auth)' : 'Público'}`);
        logs.push(`[SUCCESS] Branch padrão: ${data.default_branch}`);
        logs.push(`[DIAGNOSTIC] Diagnóstico concluído com sucesso. O Git CLI está pronto para sincronização.`);

        setDiagnosticResult({
          success: true,
          message: `Repositório ${data.full_name} acessível e verificado com sucesso!`,
          logs
        });
      } else {
        logs.push(`[WARNING] Resposta HTTP ${response.status} do GitHub API.`);
        logs.push(`[ERROR] Falha de autenticação ou repositório privado sem token válido.`);
        logs.push(`[GUIDE] Dica: Certifique-se de configurar um Personal Access Token com escopo 'repo' válido.`);

        setDiagnosticResult({
          success: false,
          message: `Falha na verificação: HTTP ${response.status} (${response.statusText}). Verifique as credenciais.`,
          logs
        });
      }
    } catch (err: any) {
      logs.push(`[ERROR] Exceção de rede durante o diagnóstico: ${err.message || 'Erro desconhecido'}`);
      logs.push(`[GUIDE] Verifique sua conexão com a internet ou se a URL do repositório está correta.`);

      setDiagnosticResult({
        success: false,
        message: `Erro de rede ao conectar com o GitHub: ${err.message}`,
        logs
      });
    } finally {
      setDiagnosing(false);
    }
  };

  const lastSyncStatus = localStorage.getItem('nerlive_last_sync_status') || 'Pendente de sincronização';
  const lastSyncTime = localStorage.getItem('nerlive_last_sync_time') || 'Nunca';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <TerminalSquare className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">GitSetupManager & Diagnóstico de Conexão</h2>
            <p className="text-xs text-slate-400">Gerencie a URL remota, chaves SSH/PAT e execute testes de conectividade com o GitHub CLI.</p>
          </div>
        </div>

        {/* Sync Status Badge */}
        <div className="px-4 py-2 rounded-xl border border-slate-700 bg-slate-950 flex items-center space-x-3">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
          <div className="text-xs">
            <div className="text-slate-400 font-mono">Último Status Git:</div>
            <div className="text-white font-bold">{lastSyncStatus} ({lastSyncTime})</div>
          </div>
        </div>
      </div>

      {savedSuccess && (
        <div className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-200 px-4 py-3 rounded-xl flex items-center space-x-3 shadow-lg">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <span className="text-sm font-medium">Configurações do Git salvas com sucesso!</span>
        </div>
      )}

      {diagnosticResult && (
        <div className={`p-5 rounded-xl border space-y-3 ${
          diagnosticResult.success ? 'bg-emerald-950/20 border-emerald-500/30 text-emerald-200' : 'bg-red-950/20 border-red-500/30 text-red-200'
        }`}>
          <div className="flex items-center space-x-2">
            {diagnosticResult.success ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <AlertTriangle className="w-5 h-5 text-red-400" />}
            <span className="text-sm font-bold">{diagnosticResult.message}</span>
          </div>
          <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-800 font-mono text-[11px] text-slate-300 space-y-1 max-h-48 overflow-y-auto">
            {diagnosticResult.logs.map((log, idx) => (
              <div key={idx} className={log.includes('ERROR') ? 'text-red-400' : log.includes('SUCCESS') ? 'text-emerald-400' : 'text-slate-400'}>
                {log}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Form / Manager */}
      <form onSubmit={handleSave} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">URL do Repositório Remoto (Git Remote)</label>
            <input
              type="text"
              value={repoUrl}
              onChange={(e) => setRepoUrl(e.target.value)}
              placeholder="https://github.com/Niiix-easy/NerLive.git"
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-sm text-white font-mono focus:outline-none focus:border-violet-500"
            />
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-2">Chave SSH / PAT do GitHub</label>
            <div className="relative">
              <input
                type={showSshKey ? 'text' : 'password'}
                value={sshKey}
                onChange={(e) => setSshKey(e.target.value)}
                placeholder="ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAI..."
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 pr-10 text-sm text-white font-mono focus:outline-none focus:border-violet-500"
              />
              <button
                type="button"
                onClick={() => setShowSshKey(!showSshKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                {showSshKey ? 'Ocultar' : 'Ver'}
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={handleRunDiagnostic}
            disabled={diagnosing}
            className="w-full sm:w-auto px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center justify-center space-x-2 transition-colors border border-slate-700 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 text-violet-400 ${diagnosing ? 'animate-spin' : ''}`} />
            <span>{diagnosing ? 'Executando Diagnóstico...' : 'Executar Teste de Conectividade (Ping / Auth)'}</span>
          </button>

          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-2.5 bg-violet-600 hover:bg-violet-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-violet-600/30 transition-all"
          >
            Salvar Configurações Git
          </button>
        </div>
      </form>
    </div>
  );
}
