import { useGitHubStatus } from '../hooks/useGitHubStatus';
import { Key, AlertTriangle, CheckCircle2, Globe } from 'lucide-react';

export function GitHubStatus() {
  const status = useGitHubStatus();

  if (status.loading) {
    return (
      <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl animate-pulse">
        <div className="h-4 bg-slate-800 rounded w-1/3 mb-4"></div>
        <div className="h-8 bg-slate-800 rounded w-full"></div>
      </div>
    );
  }

  return (
    <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Status da Conexão GitHub OAuth & APP_URL</h3>
            <p className="text-xs text-slate-400">Verificação automática em tempo real via hook <code className="text-violet-300">useGitHubStatus</code></p>
          </div>
        </div>
        <div className={`px-3.5 py-1.5 rounded-xl border flex items-center space-x-2 text-xs font-mono font-semibold ${
          status.isConfigured
            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
            : 'bg-amber-500/10 border-amber-500/30 text-amber-400'
        }`}>
          {status.isConfigured ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
          <span>{status.isConfigured ? 'Conectado e Configurado' : 'Atenção Necessária'}</span>
        </div>
      </div>

      {status.warningMessage && (
        <div className="bg-amber-500/20 border border-amber-500/30 text-amber-200 px-4 py-3 rounded-xl flex items-center space-x-3 text-xs shadow-lg">
          <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>{status.warningMessage}</span>
        </div>
      )}

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">GITHUB_CLIENT_ID</span>
          <span className={`text-xs font-mono font-bold ${status.hasClientId ? 'text-emerald-400' : 'text-red-400'}`}>
            {status.hasClientId ? 'Configurado' : 'Ausente'}
          </span>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">GITHUB_CLIENT_SECRET</span>
          <span className={`text-xs font-mono font-bold ${status.hasClientSecret ? 'text-emerald-400' : 'text-red-400'}`}>
            {status.hasClientSecret ? 'Configurado' : 'Ausente'}
          </span>
        </div>
        <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between">
          <span className="text-xs text-slate-400">APP_URL (Callback)</span>
          <span className={`text-xs font-mono font-bold ${status.hasAppUrl ? 'text-emerald-400' : 'text-amber-400'}`} title={status.appUrl}>
            {status.hasAppUrl ? 'Válida' : 'Verificar'}
          </span>
        </div>
      </div>
    </div>
  );
}
