import { useState } from 'react';
import { Rocket, Server, CheckCircle2, AlertTriangle, RefreshCw, Copy, Check, Terminal, ShieldCheck, ToggleLeft, ToggleRight } from 'lucide-react';

interface DeploymentItem {
  id: string;
  version: string;
  branch: string;
  status: 'success' | 'building' | 'failed';
  triggeredBy: string;
  timestamp: string;
}

export function DeploymentOrchestrator() {
  const [targetBranch, setTargetBranch] = useState<string>('main');
  const [deploySecret, setDeploySecret] = useState<string>(localStorage.getItem('nerlive_deploy_secret') || 'sec_nerlive_prod_998877');
  const [monitoringActive, setMonitoringActive] = useState<boolean>(true);
  const [deploying, setDeploying] = useState<boolean>(false);
  const [deployLogs, setDeployLogs] = useState<DeploymentItem[]>([
    {
      id: 'dep-101',
      version: 'v2.4.0',
      branch: 'main',
      status: 'success',
      triggeredBy: 'GitHub Webhook (Push)',
      timestamp: '2026-11-12 17:14:41'
    },
    {
      id: 'dep-100',
      version: 'v2.3.8',
      branch: 'main',
      status: 'success',
      triggeredBy: 'Manual Trigger',
      timestamp: '2026-11-11 12:00:00'
    }
  ]);

  const [copiedUrl, setCopiedUrl] = useState<boolean>(false);
  const deployWebhookUrl = `${window.location.origin}/api/deploy/webhook`;

  const handleCopyUrl = () => {
    navigator.clipboard.writeText(deployWebhookUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 3000);
  };

  const handleTriggerManualDeploy = () => {
    setDeploying(true);
    setTimeout(() => {
      const newDep: DeploymentItem = {
        id: `dep-${Date.now().toString().slice(-4)}`,
        version: `v2.4.${Math.floor(Math.random() * 10) + 1}`,
        branch: targetBranch,
        status: 'success',
        triggeredBy: 'Manual Trigger (Orchestrator)',
        timestamp: new Date().toLocaleString()
      };
      setDeployLogs([newDep, ...deployLogs]);
      setDeploying(false);
    }, 1500);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-emerald-600/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Rocket className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">DeploymentOrchestrator & CI/CD Pipeline</h2>
            <p className="text-xs text-slate-400">Orquestre webhooks de deploy automático em produção a cada push na branch principal.</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => setMonitoringActive(!monitoringActive)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold flex items-center space-x-2 transition-all border ${
              monitoringActive
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-slate-800 border-slate-700 text-slate-400'
            }`}
          >
            {monitoringActive ? <ToggleRight className="w-4 h-4 text-emerald-400" /> : <ToggleLeft className="w-4 h-4 text-slate-500" />}
            <span>{monitoringActive ? 'Monitoramento Push Ativo' : 'Monitoramento Pausado'}</span>
          </button>

          <button
            onClick={handleTriggerManualDeploy}
            disabled={deploying}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors shadow-lg shadow-emerald-600/30 disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${deploying ? 'animate-spin' : ''}`} />
            <span>{deploying ? 'Executando Build...' : 'Disparar Deploy Manual'}</span>
          </button>
        </div>
      </div>

      {/* Webhook Configuration Box */}
      <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-white flex items-center space-x-2">
            <Server className="w-4 h-4 text-emerald-400" />
            <span>Status dos Webhooks & Monitoramento da Branch Main</span>
          </h3>
          <span className={`text-xs font-mono font-bold px-3 py-1 rounded-full border ${
            monitoringActive ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-amber-500/20 text-amber-300 border-amber-500/30'
          }`}>
            {monitoringActive ? 'Escutando Push Events (main)' : 'Monitoramento Inativo'}
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1.5">Payload URL (GitHub Webhooks)</label>
            <div className="flex items-center space-x-2">
              <input
                type="text"
                readOnly
                value={deployWebhookUrl}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono text-cyan-300"
              />
              <button
                onClick={handleCopyUrl}
                className="bg-slate-800 hover:bg-slate-700 p-2.5 rounded-xl text-white transition-colors"
                title="Copiar URL"
              >
                {copiedUrl ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-mono text-slate-400 mb-1.5">Secret Token (Assinatura HMAC)</label>
            <input
              type="text"
              value={deploySecret}
              onChange={(e) => {
                setDeploySecret(e.target.value);
                localStorage.setItem('nerlive_deploy_secret', e.target.value);
              }}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs font-mono text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 pt-2 font-mono">
          <span>Branch Alvo: <strong className="text-emerald-400">{targetBranch}</strong></span>
          <span className="text-emerald-400">Status do Listener: Ativo (200 OK)</span>
        </div>
      </div>

      {/* Deployment History Table */}
      <div className="space-y-3">
        <h3 className="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Histórico de Implantações (Deploys)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-mono text-slate-400 uppercase">
                <th className="py-3 px-4">Versão</th>
                <th className="py-3 px-4">Branch</th>
                <th className="py-3 px-4">Acionado Por</th>
                <th className="py-3 px-4">Data / Hora</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-sm">
              {deployLogs.map((dep) => (
                <tr key={dep.id} className="hover:bg-slate-950/40 transition-colors">
                  <td className="py-4 px-4 font-bold text-white font-mono">{dep.version}</td>
                  <td className="py-4 px-4 text-slate-300 font-mono text-xs">{dep.branch}</td>
                  <td className="py-4 px-4 text-slate-300">{dep.triggeredBy}</td>
                  <td className="py-4 px-4 text-slate-400 font-mono text-xs">{dep.timestamp}</td>
                  <td className="py-4 px-4">
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 capitalize flex items-center space-x-1.5 w-max">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>{dep.status}</span>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
