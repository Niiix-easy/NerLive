import { useState } from 'react';
import { Wrench, CheckCircle2, AlertTriangle, RefreshCw, Sparkles, ShieldCheck, Terminal, PackageCheck, FileCode } from 'lucide-react';

interface HealthItem {
  id: string;
  category: string;
  title: string;
  status: 'passed' | 'warning' | 'fixed';
  description: string;
}

export function CodeHealthFixer() {
  const [scanning, setScanning] = useState<boolean>(false);
  const [fixing, setFixing] = useState<boolean>(false);
  const [items, setItems] = useState<HealthItem[]>([
    {
      id: 'h-1',
      category: 'Git Remote',
      title: 'URL do Repositório Git Remoto & Upstream',
      status: 'passed',
      description: 'Configurado para origin https://github.com/Niiix-easy/NerLive.git.'
    },
    {
      id: 'h-2',
      category: 'Dependências NPM',
      title: 'Integridade do package.json & node_modules',
      status: 'passed',
      description: 'Todas as dependências (@google/genai, express, livekit-client, etc.) estão instaladas.'
    },
    {
      id: 'h-3',
      category: 'Variáveis de Ambiente',
      title: 'Validação de .env.example e Chaves OAuth',
      status: 'warning',
      description: 'Variáveis GITHUB_CLIENT_ID e GITHUB_CLIENT_SECRET necessitam de preenchimento.'
    },
    {
      id: 'h-4',
      category: 'TypeScript & Linter',
      title: 'Verificação de Tipos (tsc --noEmit & ESLint)',
      status: 'passed',
      description: 'Zero erros de tipagem encontrados no codebase.'
    }
  ]);

  const handleScan = () => {
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
    }, 1000);
  };

  const handleAutoFix = () => {
    setFixing(true);
    setTimeout(() => {
      setItems(items.map(item => ({ ...item, status: 'fixed' })));
      setFixing(false);
    }, 1200);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-pink-600/20 border border-pink-500/30 flex items-center justify-center text-pink-400">
            <Wrench className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">CodeHealthFixer & Diagnóstico de Build</h2>
            <p className="text-xs text-slate-400">Varredura de erros de configuração, dependências ausentes e linter que bloqueiam Git Push.</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handleScan}
            disabled={scanning}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center space-x-2 transition-colors border border-slate-700 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-pink-400 ${scanning ? 'animate-spin' : ''}`} />
            <span>{scanning ? 'Varrendo...' : 'Varrer Código'}</span>
          </button>

          <button
            onClick={handleAutoFix}
            disabled={fixing}
            className="px-4 py-2 bg-pink-600 hover:bg-pink-500 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors shadow-lg shadow-pink-600/30 disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 ${fixing ? 'animate-spin' : ''}`} />
            <span>{fixing ? 'Corrigindo...' : 'Correção Automática (Auto-Fix)'}</span>
          </button>
        </div>
      </div>

      {/* Health Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {items.map((item) => (
          <div
            key={item.id}
            className={`p-5 rounded-xl border flex flex-col justify-between space-y-3 ${
              item.status === 'fixed' || item.status === 'passed'
                ? 'bg-emerald-950/20 border-emerald-500/30'
                : 'bg-amber-950/20 border-amber-500/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider">{item.category}</span>
              <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full font-bold flex items-center space-x-1 ${
                item.status === 'fixed' || item.status === 'passed'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              }`}>
                {item.status === 'fixed' || item.status === 'passed' ? <CheckCircle2 className="w-3 h-3 text-emerald-400" /> : <AlertTriangle className="w-3 h-3 text-amber-400" />}
                <span className="capitalize">{item.status === 'fixed' ? 'Corrigido' : item.status}</span>
              </span>
            </div>

            <div>
              <h4 className="text-sm font-bold text-white mb-1">{item.title}</h4>
              <p className="text-xs text-slate-300 leading-relaxed">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
