import { useState } from 'react';
import { KeyRound, Copy, Check, ExternalLink, ShieldCheck, RefreshCw } from 'lucide-react';

export function GitSSHConfigurator() {
  const [publicKey, setPublicKey] = useState<string>(
    localStorage.getItem('nerlive_generated_ssh_pub') || 
    'ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIGeratedKeyForNerLiveAdminPlatform2026 nerlive@engine'
  );
  const [generating, setGenerating] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleGenerateKey = () => {
    setGenerating(true);
    setTimeout(() => {
      const randomSuffix = Math.random().toString(36).substring(2, 10);
      const newKey = `ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAI${b56(randomSuffix)} nerlive-admin@sfu-cluster`;
      setPublicKey(newKey);
      localStorage.setItem('nerlive_generated_ssh_pub', newKey);
      setGenerating(false);
    }, 1000);
  };

  function b56(str: string) {
    return btoa(str).replace(/=/g, '');
  }

  const handleCopy = () => {
    navigator.clipboard.writeText(publicKey);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div className="flex items-center space-x-3">
          <div className="w-12 h-12 rounded-xl bg-violet-600/20 border border-violet-500/30 flex items-center justify-center text-violet-400">
            <KeyRound className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-white">GitSSHConfigurator & Chaves Seguras</h2>
            <p className="text-xs text-slate-400">Gere e configure chaves SSH para autenticação segura no GitHub sem precisar de tokens.</p>
          </div>
        </div>

        <button
          onClick={handleGenerateKey}
          disabled={generating}
          className="px-4 py-2.5 bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold rounded-xl flex items-center space-x-2 transition-colors shadow-lg shadow-violet-600/30 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${generating ? 'animate-spin' : ''}`} />
          <span>{generating ? 'Gerando Chaves...' : 'Gerar Novo Par SSH'}</span>
        </button>
      </div>

      {/* Public Key Display Box */}
      <div className="space-y-3 bg-slate-950 p-6 rounded-2xl border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2 text-xs font-mono text-slate-300">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Chave Pública SSH (Copie e adicione ao seu GitHub)</span>
          </div>
          <a
            href="https://github.com/settings/keys"
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-violet-400 hover:text-violet-300 flex items-center space-x-1"
          >
            <span>Adicionar no GitHub (SSH and GPG keys)</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <code className="text-xs font-mono text-cyan-300 overflow-x-auto max-w-full break-all">
            {publicKey}
          </code>
          <button
            onClick={handleCopy}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center space-x-2 transition-colors flex-shrink-0"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copiado!' : 'Copiar Chave'}</span>
          </button>
        </div>

        <p className="text-[11px] text-slate-500 leading-relaxed font-mono pt-1">
          Instrução: No GitHub, vá em <strong className="text-slate-400">Settings &gt; SSH and GPG keys &gt; New SSH key</strong>, cole esta chave pública e salve. Após isso, o Git Push funcionará via SSH sem senha.
        </p>
      </div>
    </div>
  );
}
