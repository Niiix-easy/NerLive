import { useState } from 'react';
import { DollarSign, Users, TrendingUp, Calendar, ArrowUpRight, Download, CheckCircle2 } from 'lucide-react';
import { MOCK_TRANSACTIONS } from '../data/auditData';
import { CreatorAnalytics } from './CreatorAnalytics';

export function CreatorDashboard() {
  const [requestPayoutSuccess, setRequestPayoutSuccess] = useState<boolean>(false);

  const handleRequestPayout = () => {
    setRequestPayoutSuccess(true);
    setTimeout(() => setRequestPayoutSuccess(false), 4000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-100 space-y-8">
      {requestPayoutSuccess && (
        <div className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-200 px-4 py-3 rounded-xl flex items-center space-x-3 shadow-lg">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
          <span className="text-sm font-medium">Solicitação de saque via PIX realizada com sucesso! O valor será depositado em até 1 dia útil.</span>
        </div>
      )}

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-mono text-emerald-400 font-semibold uppercase tracking-wider">Painel Financeiro & Analytics</span>
          <h1 className="text-3xl font-black text-white mt-1">Dashboard do Criador</h1>
        </div>
        <button
          onClick={handleRequestPayout}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-emerald-600/30 transition-all flex items-center space-x-2"
        >
          <DollarSign className="w-4 h-4" />
          <span>Solicitar Saque (PIX)</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono text-slate-400">Saldo Disponível</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">R$ 2.450,00</div>
          <div className="text-xs text-emerald-400 mt-2 font-mono flex items-center space-x-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+18.4% este mês</span>
          </div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono text-slate-400">Assinantes Ativos</span>
            <div className="w-9 h-9 rounded-xl bg-violet-500/20 text-violet-400 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">1,420</div>
          <div className="text-xs text-violet-400 mt-2 font-mono">R$ 29,90 / mês por assinante</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono text-slate-400">Receita PPV (Eventos)</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center">
              <Calendar className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">R$ 4.890,00</div>
          <div className="text-xs text-indigo-400 mt-2 font-mono">12 eventos realizados</div>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-mono text-slate-400">Gorjetas & Presentes</span>
            <div className="w-9 h-9 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center">
              <ArrowUpRight className="w-5 h-5" />
            </div>
          </div>
          <div className="text-3xl font-black text-white">R$ 920,00</div>
          <div className="text-xs text-pink-400 mt-2 font-mono">Alta engajamento</div>
        </div>
      </div>

      {/* Recharts Analytics Component */}
      <CreatorAnalytics />

      {/* Ledger & Transactions Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl font-bold text-white">Extrato & Ledger Financeiro</h2>
            <p className="text-slate-400 text-sm">Histórico imutável de transações, assinaturas e repasses em centavos inteiros.</p>
          </div>
          <button className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl flex items-center space-x-2 transition-colors">
            <Download className="w-4 h-4" />
            <span>Exportar CSV</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-xs font-mono text-slate-400 uppercase">
                <th className="py-3 px-4">Data / Hora</th>
                <th className="py-3 px-4">Tipo</th>
                <th className="py-3 px-4">Descrição</th>
                <th className="py-3 px-4">Valor</th>
                <th className="py-3 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-sm">
              {MOCK_TRANSACTIONS.map((tx) => (
                <tr key={tx.id} className="hover:bg-slate-950/40 transition-colors">
                  <td className="py-4 px-4 text-slate-400 font-mono text-xs">{tx.date}</td>
                  <td className="py-4 px-4 font-semibold text-white capitalize">{tx.type.replace('_', ' ')}</td>
                  <td className="py-4 px-4 text-slate-300">{tx.description}</td>
                  <td className="py-4 px-4 font-bold text-emerald-400">R$ {(tx.amount / 100).toFixed(2)}</td>
                  <td className="py-4 px-4">
                    <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 capitalize">
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
