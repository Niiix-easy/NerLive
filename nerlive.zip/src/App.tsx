/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { Header } from './components/Header';
import { AuditReportView } from './components/AuditReportView';
import { ViewerPortal } from './components/ViewerPortal';
import { CreatorStudio } from './components/CreatorStudio';
import { CreatorDashboard } from './components/CreatorDashboard';
import { AdminPanel } from './components/AdminPanel';
import { DatabaseSchemaViewer } from './components/DatabaseSchemaViewer';
import { WebhookHealthMonitor } from './components/WebhookHealthMonitor';
import { UserRole } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<'audit' | 'viewer' | 'studio' | 'dashboard' | 'admin' | 'schema'>('audit');
  const [currentRole, setCurrentRole] = useState<UserRole>('creator');

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans antialiased selection:bg-violet-600 selection:text-white">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentRole={currentRole}
        setCurrentRole={setCurrentRole}
      />

      <main className="flex-1 pb-16">
        {activeTab === 'audit' && <AuditReportView />}
        {activeTab === 'viewer' && <ViewerPortal />}
        {activeTab === 'studio' && <CreatorStudio />}
        {activeTab === 'dashboard' && <CreatorDashboard />}
        {activeTab === 'admin' && <AdminPanel />}
        {activeTab === 'schema' && <DatabaseSchemaViewer />}
      </main>

      {/* Global Webhook Health Monitor & Toast Alerts */}
      <WebhookHealthMonitor />

      <footer className="border-t border-slate-900 bg-slate-950/80 py-6 text-center text-xs text-slate-500 font-mono">
        <p>NERLIVE Engine &copy; 2026 — Plataforma Profissional de Monetização e Transmissão ao Vivo</p>
      </footer>
    </div>
  );
}
