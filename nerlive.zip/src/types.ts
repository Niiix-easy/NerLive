export type UserRole = 'viewer' | 'creator' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  balance: number; // in cents
}

export interface CreatorProfile {
  id: string;
  userId: string;
  handle: string;
  bio: string;
  category: string;
  bannerUrl: string;
  subscribersCount: number;
  monthlySubscriptionPrice: number; // in cents
  isLive: boolean;
  currentLiveTitle?: string;
  viewersCount?: number;
}

export interface LiveEvent {
  id: string;
  creatorId: string;
  creatorName: string;
  creatorAvatar: string;
  title: string;
  description: string;
  category: string;
  thumbnailUrl: string;
  isLive: boolean;
  scheduledFor?: string;
  isPayPerView: boolean;
  price: number; // in cents
  streamKey?: string;
  playbackUrl?: string;
  viewersCount: number;
}

export interface ChatMessage {
  id: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  isTip?: boolean;
  tipAmount?: number;
  giftName?: string;
}

export interface FinancialTransaction {
  id: string;
  date: string;
  type: 'subscription' | 'pay_per_view' | 'tip' | 'gift' | 'payout' | 'platform_fee';
  description: string;
  amount: number; // in cents
  creatorId?: string;
  creatorName?: string;
  status: 'completed' | 'pending' | 'refunded';
}

export interface AuditSection {
  title: string;
  category: string;
  riskLevel: 'CRÍTICO' | 'ALTO' | 'MÉDIO' | 'BAIXO';
  summary: string;
  details: string[];
}
