import { LiveEvent, CreatorProfile, FinancialTransaction, ChatMessage } from '../types';

export const AUDIT_SECTIONS = [
  {
    title: '1. Resumo Executivo',
    category: 'Geral',
    riskLevel: 'BAIXO' as const,
    summary: 'Auditoria técnica e arquitetural da plataforma NerLive comparada a Revel, PPV Stream Rust e LiveKit.',
    details: [
      'Preservação integral do projeto React/TypeScript base existente.',
      'Definição de arquitetura modular desacoplando backend comercial, transações financeiras e motor de streaming SFU (LiveKit).',
      'Adoção de padrões de segurança OWASP e modelagem financeira imutável (ledger em centavos inteiros).'
    ]
  },
  {
    title: '2. Auditoria do Projeto A — Revel (Django/PostGIS)',
    category: 'Backend & Organização',
    riskLevel: 'MÉDIO' as const,
    summary: 'Análise de regras de negócios para eventos, memberships, organizadores e notificações.',
    details: [
      'Backend robusto em Django Ninja com suporte a PostGIS.',
      'Reaproveitamento conceitual de níveis de acesso, memberships e multi-organizadores.',
      'Adaptação para Node.js / Supabase Edge Functions na arquitetura NerLive para menor latência.'
    ]
  },
  {
    title: '3. Auditoria do Projeto B — PPV Stream Rust (Axum/FFmpeg)',
    category: 'Streaming & Ledger',
    riskLevel: 'ALTO' as const,
    summary: 'Análise de processamento de vídeo HLS, controle de acesso pós-pagamento e ledger financeiro.',
    details: [
      'Arquitetura de alto desempenho em Rust (Axum) para processamento com FFmpeg.',
      'Reaproveitamento de padrões de carteira interna (ledger imutável sem conta regulada).',
      'Isolamento de chaves de S3 e assinaturas de URLs temporárias para proteção contra hotlinking.'
    ]
  },
  {
    title: '4. Auditoria do Projeto C — LiveKit (WebRTC SFU)',
    category: 'Streaming Interativo',
    riskLevel: 'BAIXO' as const,
    summary: 'Utilização do LiveKit como motor SFU de baixíssima latência para salas de transmissão e co-hosts.',
    details: [
      'Geração de tokens JWT estritamente no backend (nunca no frontend).',
      'Validação prévia de assinaturas e pay-per-view antes da emissão do token de sala.',
      'Controle rígido de egress/ingress para gravações automáticas no storage S3.'
    ]
  },
  {
    title: '5. Matriz de Licenças Open Source',
    category: 'Jurídico & Compliance',
    riskLevel: 'BAIXO' as const,
    summary: 'Classificação de componentes para reutilização comercial segura.',
    details: [
      'LiveKit (Apache 2.0): Reutilizável com atribuição.',
      'Revel Backend (MIT): Reutilizável com adaptação de lógicas.',
      'PPV Stream Rust (MIT): Reutilizável para padrões de ledger e HLS.'
    ]
  },
  {
    title: '6. Modelagem de Dados & Ledger Financeiro',
    category: 'Banco de Dados',
    riskLevel: 'CRÍTICO' as const,
    summary: 'Estrutura PostgreSQL rigorosa com centavos inteiros e idempotência.',
    details: [
      'Tabelas essenciais: profiles, creators, events, live_sessions, subscriptions, orders, financial_ledger.',
      'Valores monetários sempre em inteiros (ex: R$ 50,00 armazenado como 5000).',
      'Políticas de Row Level Security (RLS) estritas por tenant e perfil de usuário.'
    ]
  },
  {
    title: '7. Segurança OWASP & LiveKit Rules',
    category: 'Segurança',
    riskLevel: 'CRÍTICO' as const,
    summary: 'Blindagem contra IDOR, bypass de pagamento e vazamento de tokens de transmissão.',
    details: [
      'Validação de webhook de pagamento com assinatura HMAC e idempotência.',
      'Tokens LiveKit com validade máxima de 2 horas e permissões restritas (publish/subscribe).',
      'Rate limiting em endpoints de chat e gorjetas.'
    ]
  },
  {
    title: '8. Plano de Implementação em 12 Fases',
    category: 'DevOps & Execução',
    riskLevel: 'BAIXO' as const,
    summary: 'Cronograma estruturado para evolução segura da plataforma.',
    details: [
      'Fase 1: Diagnóstico e arquitetura base (concluído).',
      'Fase 2-6: Supabase Schema, autenticação e painéis.',
      'Fase 7-12: Integração LiveKit, Gateways de Pagamento (Asaas/MercadoPago), Gravações e Testes.'
    ]
  }
];

export const MOCK_CREATORS: CreatorProfile[] = [
  {
    id: 'c1',
    userId: 'u1',
    handle: '@techmaster',
    bio: 'Engenheiro de Software sênior transmitindo arquitetura de sistemas ao vivo e code reviews.',
    category: 'Tecnologia',
    bannerUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
    subscribersCount: 1420,
    monthlySubscriptionPrice: 2990, // R$ 29,90
    isLive: true,
    currentLiveTitle: 'Construindo um Backend de Alta Performance em Rust & LiveKit',
    viewersCount: 384
  },
  {
    id: 'c2',
    userId: 'u2',
    handle: '@gabrielamusic',
    bio: 'Cantora e compositora. Shows acústicos exclusivos e backstage toda semana.',
    category: 'Música',
    bannerUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=1200&q=80',
    subscribersCount: 3150,
    monthlySubscriptionPrice: 1990,
    isLive: true,
    currentLiveTitle: 'Sessão Acústica Íntima: Pedidos do Chat & Cover Session',
    viewersCount: 712
  },
  {
    id: 'c3',
    userId: 'u3',
    handle: '@fitpro_br',
    bio: 'Treinos funcionais diários, consultoria nutricional e lives de alta intensidade.',
    category: 'Fitness',
    bannerUrl: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1200&q=80',
    subscribersCount: 890,
    monthlySubscriptionPrice: 3990,
    isLive: false
  }
];

export const MOCK_EVENTS: LiveEvent[] = [
  {
    id: 'e1',
    creatorId: 'c1',
    creatorName: 'TechMaster Brasil',
    creatorAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80',
    title: 'Construindo um Backend de Alta Performance em Rust & LiveKit',
    description: 'Aprenda do zero como estruturar um servidor de streaming de vídeo com Axum, FFmpeg e LiveKit SFU.',
    category: 'Tecnologia',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80',
    isLive: true,
    isPayPerView: false,
    price: 0,
    viewersCount: 384
  },
  {
    id: 'e2',
    creatorId: 'c2',
    creatorName: 'Gabriela Silva',
    creatorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    title: 'Sessão Acústica Íntima: Pedidos do Chat & Cover Session',
    description: 'Show exclusivo ao vivo com chat interativo, pedidos de música em tempo real e bate-papo.',
    category: 'Música',
    thumbnailUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=800&q=80',
    isLive: true,
    isPayPerView: true,
    price: 1490, // R$ 14,90
    viewersCount: 712
  },
  {
    id: 'e3',
    creatorId: 'c3',
    creatorName: 'Carlos FitPro',
    creatorAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=150&q=80',
    title: 'Masterclass: Hipertrofia Avançada & Nutrição Sem Mitos',
    description: 'Seminário fechado com Q&A ao vivo para tirar todas as dúvidas sobre treino e dieta.',
    category: 'Fitness',
    thumbnailUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=800&q=80',
    isLive: false,
    scheduledFor: '2026-11-15T20:00:00Z',
    isPayPerView: true,
    price: 4990, // R$ 49,90
    viewersCount: 0
  }
];

export const MOCK_CHAT_MESSAGES: ChatMessage[] = [
  { id: 'm1', senderName: 'Ana Souza', senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80', text: 'Que aula incrível! Esse setup com LiveKit é perfeito.', timestamp: '17:01' },
  { id: 'm2', senderName: 'Marcos Dev', senderAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?auto=format&fit=crop&w=100&q=80', text: 'Mandou demais no Rust!', timestamp: '17:02', isTip: true, tipAmount: 2000 },
  { id: 'm3', senderName: 'Juliana Costa', senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=100&q=80', text: 'Presente enviado: 🚀 Foguete Galático!', timestamp: '17:03', giftName: '🚀 Foguete Galático' },
  { id: 'm4', senderName: 'Pedro H.', senderAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80', text: 'Vai ficar gravado para assinantes?', timestamp: '17:04' }
];

export const MOCK_TRANSACTIONS: FinancialTransaction[] = [
  { id: 'tx-101', date: '2026-11-12 16:45', type: 'subscription', description: 'Assinatura Mensal - @techmaster (Ana Souza)', amount: 2990, status: 'completed' },
  { id: 'tx-102', date: '2026-11-12 16:30', type: 'pay_per_view', description: 'Ingresso PPV - Sessão Acústica Gabriela', amount: 1490, status: 'completed' },
  { id: 'tx-103', date: '2026-11-12 15:10', type: 'tip', description: 'Gorjeta para @techmaster (Marcos Dev)', amount: 2000, status: 'completed' },
  { id: 'tx-104', date: '2026-11-12 14:00', type: 'gift', description: 'Presente Virtual 🚀 Foguete (Juliana Costa)', amount: 5000, status: 'completed' },
  { id: 'tx-105', date: '2026-11-11 10:00', type: 'payout', description: 'Repasse PIX para Criador @techmaster', amount: 145000, status: 'completed' }
];
