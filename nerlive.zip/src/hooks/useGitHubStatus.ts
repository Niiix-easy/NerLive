import { useState, useEffect } from 'react';

export interface GitHubStatus {
  isConfigured: boolean;
  hasClientId: boolean;
  hasClientSecret: boolean;
  hasAppUrl: boolean;
  appUrl: string;
  warningMessage: string | null;
  loading: boolean;
}

export function useGitHubStatus(): GitHubStatus {
  const [status, setStatus] = useState<GitHubStatus>({
    isConfigured: false,
    hasClientId: false,
    hasClientSecret: false,
    hasAppUrl: false,
    appUrl: '',
    warningMessage: null,
    loading: true,
  });

  useEffect(() => {
    const checkStatus = () => {
      const clientId = import.meta.env.VITE_GITHUB_CLIENT_ID || localStorage.getItem('nerlive_github_client_id') || '';
      const clientSecret = import.meta.env.VITE_GITHUB_CLIENT_SECRET || localStorage.getItem('nerlive_github_client_secret') || '';
      
      // Check APP_URL from import.meta.env, window.location.origin, or localStorage
      const appUrl = import.meta.env.VITE_APP_URL || window.location.origin || '';

      const hasClientId = clientId.length > 0;
      const hasClientSecret = clientSecret.length > 0;
      const hasAppUrl = appUrl.length > 0 && (appUrl.startsWith('https://') || appUrl.startsWith('http://'));
      const isConfigured = hasClientId && hasClientSecret && hasAppUrl;

      let warningMessage: string | null = null;
      if (!hasAppUrl) {
        warningMessage = 'Aviso crítico: APP_URL não está configurada ou é inválida. O redirecionamento de callback do GitHub OAuth pode falhar.';
      } else if (!hasClientId || !hasClientSecret) {
        warningMessage = 'Credenciais GITHUB_CLIENT_ID ou GITHUB_CLIENT_SECRET estão ausentes.';
      }

      setStatus({
        isConfigured,
        hasClientId,
        hasClientSecret,
        hasAppUrl,
        appUrl,
        warningMessage,
        loading: false,
      });
    };

    checkStatus();
  }, []);

  return status;
}
